#include "OptivalData.h"
#include "BBId.h"
#include "VGSSettingsId.h"


OptivalData::OptivalData(QObject* parent) :
    CommunicatorClientBase(parent),
    _nbChannelsId(BBId::createId(VGS_ID_ISYS_NUMBER_OF_CHANNELS)),
    _nbChannels(0)
{
    registerId(_nbChannelsId, UpdateFrequency::Low);
}

OptivalData::~OptivalData()
{
    for(auto& ch : _channelData)
    {
        if(ch != NULL)
        {
            delete ch;
            ch = NULL;
        }
    }
    _channelData.clear();
    emit optivalChannelDataChanged();
}

int OptivalData::nbChannels()
{
    return _nbChannels;
}

void OptivalData::updateIds(QMap<Unsigned32, RC90Value> updateList)
{
    if(updateList.contains(_nbChannelsId))
    {
        _nbChannels = updateList[_nbChannelsId];
        if(_channelData.count() < _nbChannels)
        {
            for(Unsigned32 chIndex = _channelData.count(); chIndex < _nbChannels; ++chIndex)
            {
                OptivalChannelData* channelData = new OptivalChannelData(chIndex, this);
                _channelData.append(channelData);
                emit channelData->kleppenChanged();
            }
            emit optivalChannelDataChanged();
        }
//        else if(_channelData.count() > _nbChannels)
//        {
//            Unsigned32 nbItemsToRemove = _nbChannels - _channelData.count();
//            for(Unsigned32 i = 0; i < nbItemsToRemove; ++i)
//            {
//                OptivalChannelData* chData = _channelData.takeLast();
//                if(chData != NULL)
//                    chData->deleteLater();
//            }
//            emit optivalChannelDataChanged();
//        }
        emit nbChannelsChanged();
    }
}

QQmlListProperty<OptivalChannelData> OptivalData::optivalChannelData()
{
    return QQmlListProperty<OptivalChannelData>(this, this,
             &OptivalData::appendOptivalChannelData,
             &OptivalData::optivalChannelDataCount,
             &OptivalData::optivalChannelData,
             &OptivalData::clearOptivalChannelData);
}

void OptivalData::appendOptivalChannelData(OptivalChannelData* p) {
    _channelData.append(p);
    emit optivalChannelDataChanged();
}

int OptivalData::optivalChannelDataCount() const
{
    return _channelData.count();
}

OptivalChannelData *OptivalData::optivalChannelData(int index) const
{
    return _channelData.at(index);
}

void OptivalData::clearOptivalChannelData() {
    return _channelData.clear();
    emit optivalChannelDataChanged();

}

void OptivalData::appendOptivalChannelData(QQmlListProperty<OptivalChannelData>* list, OptivalChannelData* p) {
    reinterpret_cast< OptivalData* >(list->data)->appendOptivalChannelData(p);
}

void OptivalData::clearOptivalChannelData(QQmlListProperty<OptivalChannelData>* list) {
    reinterpret_cast< OptivalData* >(list->data)->clearOptivalChannelData();
}

OptivalChannelData* OptivalData::optivalChannelData(QQmlListProperty<OptivalChannelData>* list, int i) {
    return reinterpret_cast< OptivalData* >(list->data)->optivalChannelData(i);
}

int OptivalData::optivalChannelDataCount(QQmlListProperty<OptivalChannelData>* list) {
    return reinterpret_cast< OptivalData* >(list->data)->optivalChannelDataCount();
}
