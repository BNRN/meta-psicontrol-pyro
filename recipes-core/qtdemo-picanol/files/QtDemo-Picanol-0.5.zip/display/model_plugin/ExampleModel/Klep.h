#ifndef KLEP_H
#define KLEP_H

#include <QObject>
#include "PicanolTypes.h"
#include "CommunicatorClientBase.h"

class Klep: public CommunicatorClientBase
{
    Q_OBJECT

public:
    Klep(QObject *parent = NULL);
    Klep(Unsigned8 index, Unsigned8 channel, QObject *parent = NULL);
    ~Klep();

    Q_PROPERTY(float startHoek READ startHoek NOTIFY hoekChanged)
    Q_PROPERTY(float eindHoek READ eindHoek NOTIFY hoekChanged)

    Q_INVOKABLE void zetHoeken(float startHoek, float eindHoek);


public:
    float startHoek();
    void setStartHoek(float startHoek);

    float eindHoek();
    void setEindHoek(float eindHoek);

    void updateIds(QMap<Unsigned32, RC90Value> changedIds) override ;


signals:
    void hoekChanged();


private:
    float m_startHoek;
    float m_eindHoek;
    Unsigned32 _vgsid;
};

#endif // KLEP_H
