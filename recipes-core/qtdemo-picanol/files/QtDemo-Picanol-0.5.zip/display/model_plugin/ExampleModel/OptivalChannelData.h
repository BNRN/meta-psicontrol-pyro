#ifndef EXAMPLE_H
#define EXAMPLE_H

#include <QObject>
#include <QQmlListProperty>
#include <QVector>

#include "CommunicatorClientBase.h"
#include "Klep.h"
#include "Test.h"


Q_DECLARE_METATYPE(Klep*)

class OptivalChannelData :  public CommunicatorClientBase
{
    Q_OBJECT

    Q_PROPERTY(QQmlListProperty<Klep> kleppen READ kleppen NOTIFY kleppenChanged)

    Q_PROPERTY(float vasteHoofdBlazerStartHoek READ vasteHoofdBlazerStartHoek NOTIFY vasteHoofdBlazerStartHoekChanged)
    Q_PROPERTY(float vasteHoofdBlazerEindHoek READ vasteHoofdBlazerEindHoek NOTIFY vasteHoofdBlazerEindHoekChanged)

    Q_PROPERTY(float beweegbareHoofdBlazerStartHoek READ beweegbareHoofdBlazerStartHoek NOTIFY beweegbareHoofdBlazerStartHoekChanged)
    Q_PROPERTY(float beweegbareHoofdBlazerEindHoek READ beweegbareHoofdBlazerEindHoek NOTIFY beweegbareHoofdBlazerEindHoekChanged)

    Q_PROPERTY(float twinHoofdBlazerStartHoek READ twinHoofdBlazerStartHoek NOTIFY twinHoofdBlazerStartHoekChanged)
    Q_PROPERTY(float twinHoofdBlazerEindHoek READ twinHoofdBlazerEindHoek NOTIFY twinHoofdBlazerEindHoekChanged)

    Q_PROPERTY(float hoofdBlazersTankRegioDruk READ hoofdBlazersTankRegioDruk NOTIFY hoofdBlazersTankRegioDrukChanged)
    Q_PROPERTY(float bijblazerTankRegio1Druk READ bijblazerTankRegio1Druk NOTIFY bijblazerTankRegio1DrukChanged)
    Q_PROPERTY(float bijblazerTankRegio2Druk READ bijblazerTankRegio2Druk NOTIFY bijblazerTankRegio2DrukChanged)
    Q_PROPERTY(float bijblazerTankRegio3Druk READ bijblazerTankRegio3Druk NOTIFY bijblazerTankRegio3DrukChanged)


public:
    Q_INVOKABLE void notifyVisibility(bool visible);

public:

    OptivalChannelData(Unsigned32 channelIndex = 0, QObject *parent = 0);
    ~OptivalChannelData();


private slots:
    void timerExpired();



public:
    QQmlListProperty<Klep> kleppen();
    void appendKlep(Klep*);
    int kleppenCount() const;
    Klep *klep(int) const;
    void clearKleppen();


private:
    static void appendKlep(QQmlListProperty<Klep>*, Klep*);
    static int kleppenCount(QQmlListProperty<Klep>*);
    static Klep* klep(QQmlListProperty<Klep>*, int);
    static void clearKleppen(QQmlListProperty<Klep>*);

    QVector<Klep *> m_kleppen;

signals:
    void kleppenChanged();




    /**********************/
    // vaste hoofdblazer
    /**********************/

public:
    float m_vasteHoofdBlazerStartHoek;
    float m_vasteHoofdBlazerEindHoek;
    float vasteHoofdBlazerStartHoek();
    float vasteHoofdBlazerEindHoek();
signals:
    void vasteHoofdBlazerStartHoekChanged();
    void vasteHoofdBlazerEindHoekChanged();

    /**********************/
    // beweegbare hoofdblazer
    /**********************/

public:
    float m_beweegbareHoofdBlazerStartHoek;
    float m_beweegbareHoofdBlazerEindHoek;
    float beweegbareHoofdBlazerStartHoek();
    float beweegbareHoofdBlazerEindHoek();
signals:
    void beweegbareHoofdBlazerStartHoekChanged();
    void beweegbareHoofdBlazerEindHoekChanged();

    /**********************/
    // twin hoofdblazer
    /**********************/

public:
    float m_twinHoofdBlazerStartHoek;
    float m_twinHoofdBlazerEindHoek;
    float twinHoofdBlazerStartHoek();
    float twinHoofdBlazerEindHoek();
signals:
    void twinHoofdBlazerStartHoekChanged();
    void twinHoofdBlazerEindHoekChanged();


    /*********************************/
    // hoofd blazers tank regio druk
    /*********************************/
public:
    float m_hoofdBlazersTankRegioDruk;
    float hoofdBlazersTankRegioDruk();
signals:
    void hoofdBlazersTankRegioDrukChanged();

    /*********************************/
    // bijblazers tank regio 1 druk
    /*********************************/
public:
    float m_bijblazerTankRegio1Druk;
    float bijblazerTankRegio1Druk();
signals:
    void bijblazerTankRegio1DrukChanged();

    /*********************************/
    // bijblazers tank regio 2 druk
    /*********************************/
public:
    float m_bijblazerTankRegio2Druk;
    float bijblazerTankRegio2Druk();
signals:
    void bijblazerTankRegio2DrukChanged();

    /*********************************/
    // bijblazers tank regio 3 druk
    /*********************************/
public:
    float m_bijblazerTankRegio3Druk;
    float bijblazerTankRegio3Druk();
signals:
    void bijblazerTankRegio3DrukChanged();

public:
    virtual void updateIds(QMap<Unsigned32, RC90Value> changedIds);
    Unsigned32 _bijblazerdrukRegio1Id;



    Unsigned32 _channelIndex;






};

#endif // EXAMPLE_H
