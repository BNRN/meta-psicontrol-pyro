#pragma once

#include <QObject>
#include <QSet>
#include <QMap>
#include "Communicator.h"
#include "RC90Value.h"

class CommunicatorClientBase : public QObject
{

public:
    explicit CommunicatorClientBase(QObject *parent = NULL)
        : QObject(parent), _communicator(Communicator::getInstance())
    {

    }

    ~CommunicatorClientBase()
    {
        unload();
    }

    void registerId(int id, UpdateFrequency::Enum updateFrequency = UpdateFrequency::Medium)
    {
        if (_registeredIds.find(id) == _registeredIds.end())
        {
            _registeredIds.insert(id);
            _communicator.registerId(id, this, updateFrequency);
        }
    }

    void unRegisterId(int id)
    {
        if (_registeredIds.find(id) != _registeredIds.end())
        {
            _registeredIds.remove(id);
            _communicator.unRegisterId(id, this);
        }
    }

    void setId(Unsigned32 vgsid, RC90Value value)
    {
        _communicator.setId(vgsid, value);
    }

    RC90Value getValue(Unsigned32 vgsid)
    {
        return _communicator.getValue(vgsid);
    }

    RC90Values getValues(Unsigned32 vgsid)
    {
        return _communicator.getRC90Values(vgsid);
    }


    virtual void updateIds(QMap<Unsigned32, RC90Value> changedIds)
    {
        qDebug() << "updateIds not implemnted.";
    }

    void unload()
    {
        for (auto& id : _registeredIds)
            _communicator.unRegisterId(id, this);
    }

private:
    Communicator& _communicator;
    QSet<int> _registeredIds;

//    typedef void(*functionPtrRC90Value)(RC90Value);
//    QMap<int, functionPtrRC90Value> _idToSetMap;
//    typedef void(*functionPtrVoid)(void);
//    QMap<int, functionPtrVoid> _idToNotifyMap;
};
