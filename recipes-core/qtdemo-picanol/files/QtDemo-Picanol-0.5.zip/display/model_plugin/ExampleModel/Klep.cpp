#include "Klep.h"
#include "BBId.h"
#include "VGSSettingsId.h"

#include <QDebug>

Klep::Klep(QObject *parent) :
    CommunicatorClientBase(parent)
{

}

Klep::Klep(Unsigned8 index, Unsigned8 channel, QObject *parent) :
    CommunicatorClientBase(parent)
  , m_startHoek(0)
  , m_eindHoek(0)
  , _vgsid(BBId::createIdChannelIndex(VGS_ID_ISYS_CH_X_RV_X_TIMING_DEG_ACTUAL, channel, index))
{
    registerId(_vgsid, UpdateFrequency::Medium);
}

Klep::~Klep()
{
    qDebug() << "Destructing klep ch" << (Unsigned16)BBId::getIndex1(_vgsid) << "index" << (Unsigned16)BBId::getIndex2(_vgsid);
}

void Klep::updateIds(QMap<Unsigned32, RC90Value> changedIds)
{

    TimingPair tp(changedIds[_vgsid]);
    m_startHoek = tp.first;
    m_eindHoek = tp.second;

//    qDebug() << "Received value for id" << BBId::asString(_vgsid) << tp;

    emit hoekChanged();

}

float Klep::startHoek()
{
    return m_startHoek;
}

void Klep::setStartHoek(float startHoek)
{
    m_startHoek = startHoek;
    emit hoekChanged();
}

float Klep::eindHoek()
{
    return m_eindHoek;
}

void Klep::setEindHoek(float eindHoek)
{
    m_eindHoek = eindHoek;
    emit hoekChanged();
}

void Klep::zetHoeken(float startHoek, float eindHoek)
{
    TimingPair tp(startHoek, eindHoek);
    setId(_vgsid, tp);
}
