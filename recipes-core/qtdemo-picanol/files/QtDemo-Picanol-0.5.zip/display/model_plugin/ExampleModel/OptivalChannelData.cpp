#include <QTimer>
#include "OptivalChannelData.h"
#include "Communicator.h"

#include "BBId.h"
#include "VGSSettingsId.h"

int static randInteger(int low, int high)
{
   // Random number between low and high
   return qrand() % ((high + 1) - low) + low;
}

OptivalChannelData::OptivalChannelData(Unsigned32 channelIndex, QObject *parent) :
    CommunicatorClientBase(parent)
  , m_vasteHoofdBlazerStartHoek(50)
  , m_vasteHoofdBlazerEindHoek(150)
  , m_beweegbareHoofdBlazerStartHoek(50)
  , m_beweegbareHoofdBlazerEindHoek(50)
  , m_twinHoofdBlazerStartHoek(50)
  , m_twinHoofdBlazerEindHoek(50)
  , m_bijblazerTankRegio1Druk(5.0)
  , m_bijblazerTankRegio2Druk(5.0)
  , m_bijblazerTankRegio3Druk(5.0)
  , m_hoofdBlazersTankRegioDruk(3.7)
  , _bijblazerdrukRegio1Id(BBId::createId(VGS_ID_ISYS_PRESSUREREGULATOR_RELAY_X_PRESSURE))
  , _channelIndex(channelIndex)
{
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timerExpired()));
    //timer->start(100);


    //m_communicator.registerId(100);

    // adding dummy data
    for (int i=0; i<25; i++)
    {
//        int startHoek = randInteger(0,50);
//        int eindHoek = randInteger(120, 360);
        this->appendKlep(new Klep(i /*index*/, _channelIndex/*channel*/));

    }

    registerId(_bijblazerdrukRegio1Id);

}

OptivalChannelData::~OptivalChannelData()
{
    // unregister from ids happens in destructor of the base class
    for(auto& klep : m_kleppen)
    {
        if(klep != NULL)
        {
            delete klep;
            klep = NULL;
        }
    }
    m_kleppen.clear();
//    emit kleppenChanged();
}



void OptivalChannelData::timerExpired() {

    if (m_kleppen.size())
    {

        auto startHoek = randInteger(0,50);
        auto eindHoek = randInteger(120, 360);
        m_kleppen.at(0)->setStartHoek(startHoek);
        m_kleppen.at(0)->setEindHoek(eindHoek);
    }

}

void OptivalChannelData::notifyVisibility(bool visible)
{
    if(visible)
    {

    }
    else
    {

    }

}

QQmlListProperty<Klep> OptivalChannelData::kleppen()
{
    return QQmlListProperty<Klep>(this, this,
             &OptivalChannelData::appendKlep,
             &OptivalChannelData::kleppenCount,
             &OptivalChannelData::klep,
             &OptivalChannelData::clearKleppen);
}

void OptivalChannelData::appendKlep(Klep* p) {
    m_kleppen.insert(0, p);
    emit kleppenChanged();
}

int OptivalChannelData::kleppenCount() const
{
    return m_kleppen.count();
}

Klep *OptivalChannelData::klep(int index) const
{
    return m_kleppen.at(index);
}

void OptivalChannelData::clearKleppen() {
    return m_kleppen.clear();
    emit kleppenChanged();

}

void OptivalChannelData::appendKlep(QQmlListProperty<Klep>* list, Klep* p) {
    reinterpret_cast< OptivalChannelData* >(list->data)->appendKlep(p);
}

void OptivalChannelData::clearKleppen(QQmlListProperty<Klep>* list) {
    reinterpret_cast< OptivalChannelData* >(list->data)->clearKleppen();
}

Klep* OptivalChannelData::klep(QQmlListProperty<Klep>* list, int i) {
    return reinterpret_cast< OptivalChannelData* >(list->data)->klep(i);
}

int OptivalChannelData::kleppenCount(QQmlListProperty<Klep>* list) {
    return reinterpret_cast< OptivalChannelData* >(list->data)->kleppenCount();
}

float OptivalChannelData::vasteHoofdBlazerStartHoek()
{
    return m_vasteHoofdBlazerStartHoek;
}

float OptivalChannelData::vasteHoofdBlazerEindHoek()
{
    return m_vasteHoofdBlazerEindHoek;
}

float OptivalChannelData::beweegbareHoofdBlazerStartHoek()
{
    return m_beweegbareHoofdBlazerStartHoek;
}

float OptivalChannelData::beweegbareHoofdBlazerEindHoek()
{
    return m_beweegbareHoofdBlazerEindHoek;
}

float OptivalChannelData::twinHoofdBlazerStartHoek()
{
    return m_twinHoofdBlazerStartHoek;
}

float OptivalChannelData::twinHoofdBlazerEindHoek()
{
    return m_twinHoofdBlazerEindHoek;
}

float OptivalChannelData::hoofdBlazersTankRegioDruk()
{
    return m_hoofdBlazersTankRegioDruk;
}

float OptivalChannelData::bijblazerTankRegio1Druk()
{
    return m_bijblazerTankRegio1Druk;
}

float OptivalChannelData::bijblazerTankRegio2Druk()
{
    return m_bijblazerTankRegio2Druk;
}

float OptivalChannelData::bijblazerTankRegio3Druk()
{
    return m_bijblazerTankRegio3Druk;
}

void OptivalChannelData::updateIds(QMap<Unsigned32, RC90Value> changedIds)
{
    // update ids
    for(auto& vgsid : changedIds.keys())
    {
        if(vgsid == _bijblazerdrukRegio1Id)
            m_bijblazerTankRegio1Druk = changedIds[vgsid];
//        else if(vgsid == _etuCorrectionFactorId)
//            _etuCorrectionFactor = changedIds[vgsid];
//        else if(vgsid == _relayValveCh1Index1TimingId)
//            _timingPair = changedIds[vgsid];
//        else if(vgsid == _systemTimeId)
//            _systemTime = changedIds[vgsid];
        else
            qDebug() << "Got an id in which we're not interested" << BBId::getBaseId(vgsid);
    }

    // notify gui
    for(auto& vgsid : changedIds.keys())
    {
        if(vgsid == _bijblazerdrukRegio1Id)
            emit bijblazerTankRegio1DrukChanged();
//        else if(vgsid == _etuCorrectionFactorId)
//            emit etuCorrectionFactorChanged();
//        else if(vgsid == _relayValveCh1Index1TimingId)
//            emit timingPairChanged();
//        else if(vgsid == _systemTimeId)
//            emit systemTimeChanged();
    }
}




