#pragma once
#include <QObject>
#include <QQmlListProperty>
#include <QVector>

#include "CommunicatorClientBase.h"
#include "OptivalChannelData.h"

class OptivalData : public CommunicatorClientBase
{
    Q_OBJECT

public:
    explicit OptivalData(QObject* parent = NULL);
    ~OptivalData();


    Q_PROPERTY(QQmlListProperty<OptivalChannelData> optivalChannelData READ optivalChannelData NOTIFY optivalChannelDataChanged)
    Q_PROPERTY(int nbChannels READ nbChannels NOTIFY nbChannelsChanged)

signals:
    void optivalChannelDataChanged();
    void nbChannelsChanged();

public:
    void updateIds(QMap<Unsigned32, RC90Value> updateList) override;

    int nbChannels();

    QQmlListProperty<OptivalChannelData> optivalChannelData();
    void appendOptivalChannelData(OptivalChannelData*);
    int optivalChannelDataCount() const;
    OptivalChannelData *optivalChannelData(int) const;
    void clearOptivalChannelData();

private:
    static void appendOptivalChannelData(QQmlListProperty<OptivalChannelData>*, OptivalChannelData*);
    static int optivalChannelDataCount(QQmlListProperty<OptivalChannelData>*);
    static OptivalChannelData* optivalChannelData(QQmlListProperty<OptivalChannelData>*, int);
    static void clearOptivalChannelData(QQmlListProperty<OptivalChannelData>*);

private:
    QVector<OptivalChannelData*> _channelData;
    Unsigned32 _nbChannelsId;
    Unsigned32 _nbChannels;
};
