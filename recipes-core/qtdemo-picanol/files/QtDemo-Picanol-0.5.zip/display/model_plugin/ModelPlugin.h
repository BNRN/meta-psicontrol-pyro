#ifndef SETTINGS_PLUGIN_H
#define SETTINGS_PLUGIN_H

#include <QQmlExtensionPlugin>

class SettingsPlugin : public QQmlExtensionPlugin
{
    Q_OBJECT
    Q_PLUGIN_METADATA(IID "org.qt-project.Qt.QQmlExtensionInterface")

public:
    void registerTypes(const char *uri);
};

#endif // SETTINGS_PLUGIN_H

