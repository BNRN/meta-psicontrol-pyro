#pragma once
#include <QObject>
#include <string>

class GlobalVariables : public QObject
{
    Q_OBJECT
public:
    static bool USE_RC_FILE;
    static std::string IP_ADDRESS;

    Q_INVOKABLE static void setFileRcClient(bool isFileClient);
    Q_INVOKABLE static void setIpAddress(QString ip);

};


