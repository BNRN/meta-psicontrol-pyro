#include "GlobalVariables.h"

bool GlobalVariables::USE_RC_FILE = false;

std::string GlobalVariables::IP_ADDRESS = "10.0.182.228";  // default sim3

void GlobalVariables::setFileRcClient(bool isFileClient)
{
    USE_RC_FILE = isFileClient;
}

void GlobalVariables::setIpAddress(QString ip)
{
    IP_ADDRESS = ip.toStdString();
}
