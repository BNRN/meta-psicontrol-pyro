#include "ModelPlugin.h"
#include "OptivalChannelData.h"
#include "Klep.h"
#include "OptivalData.h"
#include "GlobalVariables.h"

#include <qqml.h>

void SettingsPlugin::registerTypes(const char *uri)
{
    qmlRegisterType<OptivalData>(uri, 1, 0, "OptivalData");
    // @uri ExampleModelPlugin
    qmlRegisterType<OptivalChannelData>(uri, 1, 0, "ExampleModel");
     //qmlRegisterType<WarningLights>(uri, 1, 0, "WarningLights");

    qmlRegisterType<Klep>(uri, 1,0, "Klep");

    qmlRegisterType<GlobalVariables>(uri, 1,0, "GlobalVariables");

}


