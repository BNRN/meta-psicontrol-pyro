#pragma once
#include <QObject>
#include <QThread>
#include "ByteConverter.h"
#include "RC90Client.h"

class ParameterPuller : public QObject
{
    Q_OBJECT

public:
    explicit ParameterPuller(QObject* parent = NULL);
    ~ParameterPuller();

    void registerId(Unsigned32 id);
    void unregisterId(Unsigned32 id);

private:
    RC90Client _rc90client;
    QThread _parameterPullerThread;
};
