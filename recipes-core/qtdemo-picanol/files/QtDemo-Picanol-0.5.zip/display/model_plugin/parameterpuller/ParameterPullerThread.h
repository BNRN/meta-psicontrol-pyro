#pragma once
#include <QThread>
#include <QMutex>
#include <QReadWriteLock>
#include <QMap>
#include <QSet>
#include <QPair>
#include "ByteConverter.h"
#include "RC90BaseClient.h"
#include "UpdateFrequency.h"
#include "RC90Value.h"
#include "ParameterData.h"

typedef QMap<Unsigned32, RC090Packet> UpdateList;

class ParameterPullerThread : public QThread
{
    Q_OBJECT

public:
    ParameterPullerThread(ParameterData& _parameterData, QObject* parent = NULL);
    ~ParameterPullerThread();

    virtual void run();
    virtual void terminate();

    void registerId(Unsigned32 id, UpdateFrequency::Enum updateFrequency = UpdateFrequency::Medium);
    void unregisterId(Unsigned32 id);
    void addToSetList(Unsigned32 id, RC90Value value);

    UpdateList getChangedIds();

signals:
    void resultReady(UpdateList updateList);

public slots:
    void receivedRCPacket(RC090Packet rcPacket);

private:
    void _modifyIds();
    void _requestIds();
    QList<Unsigned32> _addToCurrentUpdateList(QList<Unsigned32> fullIdList, Unsigned32 interval);
    void _modifyId(const QPair<Unsigned32, RC90Value>& idValuePair);

    void _sendRcPacket(RC090Packet rcPacket, bool notifyFailure=false, Unsigned32 retries=0);

private:
    static const Unsigned32 _parameterPullerUpdateInterval;
    static const bool _sync;
    static const Unsigned32 _rcMsTimeout;

    ParameterData& _parameterData;
    bool _stop;
    Unsigned32 _intervalCounter;
    Unsigned32 _nbConsecutiveTimeouts;
    RC90BaseClient* _rc90client;

    QSet<Unsigned32> _singleShotImmediateRequestList;  // shared between threads

    QMap<UpdateFrequency::Enum, QSet<Unsigned32>> _idsToBePulled;  // shared between threads

    QMap<UpdateFrequency::Enum, QSet<Unsigned32>> _currentPulledIds;

    // It's is important (because efficient) that the update frequencies are multiples of each other
    QSet<Unsigned32> _idListFreq9600ms; // x10
    QSet<Unsigned32> _idListFreq960ms; // x4
    QSet<Unsigned32> _idListFreq240ms; // x3
    QSet<Unsigned32> _idListFreq80ms; // x2
    QSet<Unsigned32> _idListFreq40ms;

    UpdateList _lastValues;
    UpdateList _changedIds;  // shared between threads

    QMutex _mutexChangedList;  // protects _changedIds
    QMutex _mutexSingleShotList;  // protects _singleShotImmediateRequestList
    QReadWriteLock _lockPullList;  // protects _idsToBePulled
    QMutex _mutexSetList;  // protects _setList & _delayedSetList

    QList<QPair<Unsigned32, RC90Value>> _setList;  // shared between threads


};
