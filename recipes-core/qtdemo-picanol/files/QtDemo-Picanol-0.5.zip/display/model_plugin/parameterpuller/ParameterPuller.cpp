#include "ParameterPuller.h"

ParameterPuller::ParameterPuller(QObject* parent):
    QObject(parent),
    _rc90client("10.0.182.226", 9060, true),
    _parameterPullerThread()
{

}


ParameterPuller::~ParameterPuller()
{

}
