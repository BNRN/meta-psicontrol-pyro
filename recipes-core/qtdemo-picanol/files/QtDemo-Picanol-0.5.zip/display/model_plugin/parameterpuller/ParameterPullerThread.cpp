#include "ParameterPullerThread.h"
#include "BBId.h"
#include "rcexception.h"
#include "RC90Client.h"
#include "RC90FileClient.h"
#include <QTimer>
#include <QTime>
#include "Global/GlobalVariables.h"


const Unsigned32 ParameterPullerThread::_parameterPullerUpdateInterval = 40;  // 40 fastest update interval
const bool ParameterPullerThread::_sync = true;
const Unsigned32 ParameterPullerThread::_rcMsTimeout = 100;

ParameterPullerThread::ParameterPullerThread(ParameterData& _parameterData, QObject* parent) :
    QThread(parent),
    _parameterData(_parameterData),
    _stop(false),
    _intervalCounter(0),
    _nbConsecutiveTimeouts(0),
    _rc90client(NULL),
    _mutexChangedList(QMutex::Recursive),
    _mutexSingleShotList(QMutex::Recursive),
    _lockPullList(QReadWriteLock::Recursive),
    _mutexSetList(QMutex::Recursive)

{
    _idsToBePulled.insert(UpdateFrequency::VeryHigh, QSet<Unsigned32>());
    _idsToBePulled.insert(UpdateFrequency::High, QSet<Unsigned32>());
    _idsToBePulled.insert(UpdateFrequency::Medium, QSet<Unsigned32>());
    _idsToBePulled.insert(UpdateFrequency::Low, QSet<Unsigned32>());
    _idsToBePulled.insert(UpdateFrequency::VeryLow, QSet<Unsigned32>());

    _currentPulledIds.unite(_idsToBePulled);
}

ParameterPullerThread::~ParameterPullerThread()
{

}

void ParameterPullerThread::registerId(Unsigned32 id, UpdateFrequency::Enum updateFrequency)
{
    // first: check if id is already in a list
    bool alreadyInUpdateList = false;
    UpdateFrequency::Enum currentUpdateFrequency = UpdateFrequency::Medium;
    _lockPullList.lockForRead();
    for(auto& freq : _idsToBePulled.keys())
    {
        if(_idsToBePulled[freq].contains(id))
        {
            alreadyInUpdateList = true;
            currentUpdateFrequency = freq;
        }
    }
    _lockPullList.unlock();

    if(not alreadyInUpdateList)
    {
        _mutexSingleShotList.lock();
        _singleShotImmediateRequestList.insert(id);
        _mutexSingleShotList.unlock();


        _lockPullList.lockForWrite();
        _idsToBePulled[updateFrequency].insert(id);
        _lockPullList.unlock();
    }
    else
    {
        if(currentUpdateFrequency > updateFrequency)
        {
            qDebug() << "Current update frequency is higher than requested frequency -> stays at current frequency";
        }
        else if(currentUpdateFrequency < updateFrequency)
        {
            qDebug() << "Current update frequency is lower than requested frequency -> bumping up frequency";
            // unregister id from current idList:
            _mutexSingleShotList.lock();
            _singleShotImmediateRequestList.insert(id);
            _mutexSingleShotList.unlock();

            _lockPullList.lockForWrite();
            for(auto& set : _idsToBePulled)
            {
                if(set.contains(id))
                    set.remove(id);
            }
            _idsToBePulled[updateFrequency].insert(id);
            _lockPullList.unlock();
        }
        else
        {
            qDebug() << "Requested update frequency equals current frequency.";
        }
    }

}
void ParameterPullerThread::unregisterId(Unsigned32 id)
{
    _lockPullList.lockForWrite();
    for(auto& set : _idsToBePulled)
    {
        if(set.contains(id))
            set.remove(id);
    }
    _lockPullList.unlock();
}


void ParameterPullerThread::run()
{

    if(GlobalVariables::USE_RC_FILE)
    {
        qDebug() << "Using file RC Client";
        _rc90client = new RC90FileClient("allIdFile.rc");
    }
    else
    {
        qDebug() << "Using UDP RC Client on address" << QString::fromStdString(GlobalVariables::IP_ADDRESS);
        _rc90client = new RC90Client(GlobalVariables::IP_ADDRESS, 9060, _sync);
    }

    if(not _sync)
    {
        connect(_rc90client, &RC90Client::receivedRCPacket, this, &ParameterPullerThread::receivedRCPacket);
    }
    QTime timeMonitor;
    timeMonitor.start();
    while(not _stop)
    {
        try
        {
            timeMonitor.restart();
            _modifyIds();
//            qDebug() << "1";
            int timeAfterModifies = timeMonitor.elapsed();
            _requestIds();
//            qDebug() << "2";
            int timeAfterRequest = timeMonitor.elapsed();

            if((float)timeAfterRequest > _parameterPullerUpdateInterval * 0.9 /*ms*/)
            {
                qDebug() << "Warning: elapsed time (" << timeAfterRequest << "ms) close to or over maxTime (" << _parameterPullerUpdateInterval << " ms)";
            }
            Signed32 remainingTime = _parameterPullerUpdateInterval - timeMonitor.elapsed();
//            qDebug() << "3: " << remainingTime;
            // wait a bit
            if(remainingTime > 0)
            {
                QThread::msleep(remainingTime /*ms*/);
            }
//            qDebug() << "4";

        }
        catch(...)
        {
            qDebug() << "Exception in ParameterPullerThread. Continuing...";
        }
    }
    delete _rc90client;
    _rc90client = NULL;
}

void ParameterPullerThread::terminate()
{
    _stop = true;
}

void ParameterPullerThread::_modifyIds()
{
    //qDebug() << "Enter ParameterPullerThread::_modifyIds()";

    _mutexSetList.lock();
    QList<QPair<Unsigned32, RC90Value>> setList(_setList);
    _setList.clear();
    _mutexSetList.unlock();

    if(not setList.isEmpty())
    {
        qDebug() << "Modifying IDs";
    }

    while(not setList.isEmpty())
    {
        auto& debug = setList.first();
        qDebug() << "value: " << debug.second.getValueAsQString();

        _modifyId(setList.takeFirst());  // removes and returns the first element
    }
    //qDebug() << "Exit ParameterPullerThread::_modifyIds()";
}

void ParameterPullerThread::_modifyId(const QPair<Unsigned32, RC90Value>& idValuePair)
{
    qDebug() << "Enter ParameterPullerThread::_modifyId for id" << BBId::asString(idValuePair.first);
    RC090Packet packet = RC090Packet::createRequest(idValuePair.first);
    if(_parameterData.getLastRCPacket(idValuePair.first, packet))
    {
//        ByteArray prevData = packet.data;
//        qDebug() << "Previous data:" << prevData;
        RC090Packet modifyPacket = RC090Packet::createModify(packet, idValuePair.second);
//        ByteArray newData = modifyPacket.data;
//        qDebug() << "Modfied data:" << newData;
        _sendRcPacket(modifyPacket, 2 /*retries*/);
    }
    else
    {
        _sendRcPacket(packet, 2 /*retries*/);

        if(_parameterData.getLastRCPacket(idValuePair.first, packet))
        {
            RC090Packet modifyPacket = RC090Packet::createModify(packet, idValuePair.second);
            _sendRcPacket(modifyPacket, 2 /*retries*/);
        }
        else
            qDebug() << "Modify id" << BBId::getBaseId(idValuePair.first) << "failed.";
    }
}

void ParameterPullerThread::_requestIds()
{
    //qDebug() << "Enter ParameterPullerThread::_requestIds()";

    _mutexSingleShotList.lock();
    QSet<Unsigned32> immediateSetList(_singleShotImmediateRequestList);
    _singleShotImmediateRequestList.clear();
    _mutexSingleShotList.unlock();

    if(not immediateSetList.isEmpty())
    {
        qDebug() << "Doing immediate requests";
    }

    for(auto&id : immediateSetList)
    {
        _sendRcPacket(RC090Packet::createRequest(id), 0 /*retries*/);
    }



    /*
     * We updaten de "update lijst" pas als we er volledig doorgegaan zijn.
     * Zo vermijden we dat de size wijzigt als we het opvragen verdelen over verschillende update intervals
     *
    */

    _lockPullList.lockForRead();
    // make a copy
    QMap<UpdateFrequency::Enum, QSet<Unsigned32>> idsToBeAdded(_idsToBePulled);
    _lockPullList.unlock();


    if(((_intervalCounter * _parameterPullerUpdateInterval) % 40) == 0)
    {
        _idListFreq40ms = _idsToBePulled[UpdateFrequency::VeryHigh];
    }
    if(((_intervalCounter * _parameterPullerUpdateInterval) % 80) == 0)
    {
        _idListFreq80ms = _idsToBePulled[UpdateFrequency::High];
    }
    if(((_intervalCounter * _parameterPullerUpdateInterval) % 240) == 0)
    {
        _idListFreq240ms = _idsToBePulled[UpdateFrequency::Medium];
    }
    if(((_intervalCounter * _parameterPullerUpdateInterval) % 960) == 0)
    {
        _idListFreq960ms = _idsToBePulled[UpdateFrequency::Low];
    }
    if(((_intervalCounter * _parameterPullerUpdateInterval) % 9600) == 0)
    {
        _idListFreq9600ms = _idsToBePulled[UpdateFrequency::VeryLow];
    }

//    qDebug() << "request 1";

    //Request ids
    // Voor de 40 ms lijst vragen we per interval een vierde van de ids op
    QList<Unsigned32> idsToUpdateThisInterval;
    idsToUpdateThisInterval.append(_addToCurrentUpdateList(_idListFreq40ms.toList(), 40));
    idsToUpdateThisInterval.append(_addToCurrentUpdateList(_idListFreq80ms.toList(), 80));
    idsToUpdateThisInterval.append(_addToCurrentUpdateList(_idListFreq240ms.toList(), 240));
    idsToUpdateThisInterval.append(_addToCurrentUpdateList(_idListFreq960ms.toList(), 960));
    idsToUpdateThisInterval.append(_addToCurrentUpdateList(_idListFreq9600ms.toList(), 9600));

//    qDebug() << "request 2";

    if(idsToUpdateThisInterval.size() > 0)
    {
        //qDebug() << "Requesting Ids";
    }

    for(auto&id : idsToUpdateThisInterval )
    {
//        qDebug() << "starting request for" << id;
        _sendRcPacket(RC090Packet::createRequest(id), 0 /*retries*/);
//        qDebug() << "Finished request for" << id;
    }

//    qDebug() << "request 3";

    // update intervalCounter
    _intervalCounter++;
    if((_intervalCounter * _parameterPullerUpdateInterval) > 9600)
        _intervalCounter = 0;

}

QList<Unsigned32> ParameterPullerThread::_addToCurrentUpdateList(QList<Unsigned32> fullIdList, Unsigned32 interval)
{
    QList<Unsigned32> ret;
    Unsigned32 nbIds = fullIdList.size();
    Unsigned32 startIndex = nbIds * ((_intervalCounter * _parameterPullerUpdateInterval) % interval) / interval;
    Unsigned32 endIndex = nbIds * ((_intervalCounter * _parameterPullerUpdateInterval) % interval + _parameterPullerUpdateInterval) / interval;

    for(Unsigned32 i = startIndex; i < endIndex; ++i)
    {
        ret.append(fullIdList[i]);
    }
    return ret;
}

void ParameterPullerThread::receivedRCPacket(RC090Packet rcPacket)
{
//    qDebug() << "Enter ParameterPullerThread::receivedRCPacket(RC090Packet rcPacket)";

    _parameterData.receivedUpdate(QPair<Unsigned32, RC090Packet>(rcPacket.vgsId, rcPacket));

}

UpdateList ParameterPullerThread::getChangedIds()
{
    _mutexChangedList.lock();
    UpdateList changedIds(_changedIds);
    _changedIds.clear();
    _mutexChangedList.unlock();
    return changedIds;
}

void ParameterPullerThread::addToSetList(Unsigned32 id, RC90Value value)
{
    QPair<Unsigned32, RC90Value> val(id, value);
    _mutexSetList.lock();
    _setList.append(val);
    _mutexSetList.unlock();
}

void ParameterPullerThread::_sendRcPacket(RC090Packet rcPacket, bool notifyFailure, Unsigned32 retries)
{
    if(_rc90client != NULL)
    {
        if(_sync)
        {
            do
            {
                try
                {
                    receivedRCPacket(_rc90client->sendSync(rcPacket, _rcMsTimeout));
                    _nbConsecutiveTimeouts = 0;
                    break;  // no more retries
                }
                catch (const RC90Exception& e)
                {
                    // what now?
                    qDebug() << "RC90 Exception:" << e.what() << "for id" << BBId::getBaseId(rcPacket.vgsId);
                    if(retries != 0)
                        --retries;
                    _nbConsecutiveTimeouts++;
                }
            } while(retries > 0);
        }
        else
            _rc90client->sendAsync(rcPacket);
    }
}
