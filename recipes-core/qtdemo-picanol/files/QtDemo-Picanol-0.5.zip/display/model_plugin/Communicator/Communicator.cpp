#include "Communicator.h"
#include <QDebug>
#include "ByteConverter.h"
#include "RC90Packet.h"
#include "rcexception.h"
#include "CommunicatorClientBase.h"
#include "BBId.h"


static const bool USE_FILE_RC_CLIENT = false;

const Unsigned32 Communicator::_displayRefreshRate = 40;  // every 40 ms -> 25 frames/s

Communicator::Communicator() :
    _timer(NULL),
    _parameterData(),
    _parameterPullerThread(_parameterData, NULL)

{
    _timer = new QTimer();
    connect(_timer, &QTimer::timeout, this, &Communicator::refresh);
    _timer->start(_displayRefreshRate);

    _parameterPullerThread.start();
}
Communicator::~Communicator()
{
    _parameterPullerThread.quit();
    _parameterPullerThread.wait();
    _timer->stop();
    disconnect(_timer, &QTimer::timeout, this, &Communicator::refresh);
    delete _timer;
}

void Communicator::setId(Unsigned32 id, RC90Value value)
{
    _parameterPullerThread.addToSetList(id, value);
}

RC90Value Communicator::getValue(Unsigned32 vgsid)
{
    return _parameterData.getValue(vgsid);
}

RC90Values Communicator::getRC90Values(Unsigned32 vgsid)
{
    RC090Packet packet = RC090Packet::createRequest(vgsid);
    if(_parameterData.getLastRCPacket(vgsid, packet))
    {
        return RC90Values(packet);
    }
    return RC90Values();
}

void Communicator::refresh()
{
    // called by timer
    //qDebug() << "Enter Communicator::refresh()";

//    UpdateList changedIds = _parameterPullerThread.getChangedIds();
//    qc();

    UpdateList changedIds = _parameterData.update();

    QMap<CommunicatorClientBase*, QMap<Unsigned32, RC90Value>> clientMap;

    for(auto& key : changedIds.keys())
    {
        try
        {
            RC90Value value = RC90Value(changedIds[key]);
            QPair<Unsigned32, RC90Value> keyValuePair(key, value);
//            qDebug() << "Changed Id: " << BBId::getBaseId(changedIds[key].vgsId) << ":" << ByteConverter::getFloatFromData(changedIds[key].data, 0);
            // distribute changed Ids
            if(_registrations.find(key) != _registrations.end())
            {
                for(auto&client :_registrations[key])
                {
                    clientMap[client].insert(clientMap[client].end(), key, value);
                }
            }
        }
        catch (const InvalidDataException& e)
        {
            qDebug() << "InvalidDataException:" << e.what();
        }
    }

    for(auto&client : clientMap.keys())
    {
        client->updateIds(clientMap[client]);
    }
}

void Communicator::registerId(Unsigned32 id, CommunicatorClientBase* client, UpdateFrequency::Enum updateFrequency)
{
    qDebug() << "Register id: " << BBId::asString(id);
    bool newId = false;
    if(_registrations.find(id) == _registrations.end())
    {
        // new id
        _registrations.insert(id, QVector<CommunicatorClientBase*>());
        newId = true;
    }

    // check of this client is already registered for this id, if not -> register
    if(not _registrations[id].contains(client))
    {
        // new client for this id
        _registrations[id].push_back(client);
        qDebug() << "Currently " << _registrations[id].size() << " clients are interested in id " << BBId::asString(id);
    }


    // alway register - parameter pull thread handles updateFrequency changes
    _parameterPullerThread.registerId(id, updateFrequency);

}

void Communicator::unRegisterId(Unsigned32 id, CommunicatorClientBase* client)
{
    qDebug() << "Unegister id: " << BBId::asString(id);
    for(auto& key : _registrations.keys())
    {
        if(key == id)
        {
            _registrations[key].removeOne(client);

            qDebug() << "Currently " << _registrations[key].size() << " clients are interested in id " << BBId::asString(id);

            if(_registrations[key].empty())
            {
                // Last id
                _parameterPullerThread.unregisterId(id);
                _registrations.remove(id);
            }

            break;
        }
    }
}
