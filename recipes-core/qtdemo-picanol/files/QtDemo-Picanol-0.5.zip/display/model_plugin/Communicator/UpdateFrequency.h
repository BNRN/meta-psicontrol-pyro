#pragma once

struct UpdateFrequency
{
    enum Enum
    {
        // Note: hoogste frequency moet hoogste value krijgen (of je moet een groter dan kleiner dan operator voorzien...)
        VeryHigh = 4,
        High = 3,
        Medium = 2,
        Low = 1,
        VeryLow = 0
    };

};
