#pragma once

#include <QObject>
#include <memory>
#include <QUdpSocket>
#include <QMap>
#include <QVector>
#include <QTimer>

#include <iostream>
#include <future>
//#include "RC90Client.h"
#include "PicanolTypes.h"
#include "ParameterPullerThread.h"
#include "RC90Value.h"
#include "RC90Values.h"
#include "ParameterData.h"

class CommunicatorClientBase;


class Communicator : public QObject
{
    Q_OBJECT
public:
  static Communicator& getInstance()
  {
    static Communicator instance;
    return instance;
  }
private:
  Communicator();
  ~Communicator();
  Communicator(const Communicator&)= delete;
  Communicator& operator=(const Communicator&)= delete;

//  signals:
//  void updateIdToClients(Unsigned32 id, RC90Value value);

public slots:
  void refresh();

public:
  void registerId(Unsigned32 id, CommunicatorClientBase* client, UpdateFrequency::Enum updateFrequency = UpdateFrequency::Medium);
  void unRegisterId(Unsigned32 id, CommunicatorClientBase* client);
  void setId(Unsigned32 id, RC90Value value);
  RC90Value getValue(Unsigned32 vgsid);
  RC90Values getRC90Values(Unsigned32 vgsid);

private:
  static const Unsigned32 _displayRefreshRate;
  QTimer* _timer;
  QMap<Unsigned32, QVector<CommunicatorClientBase*>> _registrations;
  ParameterData _parameterData;
  ParameterPullerThread _parameterPullerThread;


};
