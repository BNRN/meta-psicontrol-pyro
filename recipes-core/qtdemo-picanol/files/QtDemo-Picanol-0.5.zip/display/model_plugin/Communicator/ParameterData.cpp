#include "ParameterData.h"
#include "BBId.h"
#include <QMutexLocker>
#include <QReadLocker>
#include <QWriteLocker>
#include <QDebug>

ParameterData::ParameterData():
    _receivedUpdatesMutex(),
    _lastReceivedValuesLock()
{
}

RC90Value ParameterData::getValue(Unsigned32 vgsid)
{
    QReadLocker rlocker(&_lastReceivedValuesLock);

    if(_lastReceivedValues.keys().contains(vgsid))
        return RC90Value(_lastReceivedValues[vgsid]);
    return RC90Value(0);
}

bool ParameterData::getLastRCPacket(Unsigned32 vgsid, RC090Packet& lastPacket)
{
    // check if the last RC packet is in the received updates list -> that's the last one received
    QMutexLocker locker(&_receivedUpdatesMutex);

    if(_receivedUpdates.contains(vgsid))
    {
        lastPacket = _receivedUpdates[vgsid];
        return true;
    }

    locker.unlock();  // no need to have it locked any further

    QReadLocker rlocker(&_lastReceivedValuesLock);

    if(_lastReceivedValues.keys().contains(vgsid))
    {
        lastPacket = _lastReceivedValues[vgsid];
        return true;
    }
    return false;
}

void ParameterData::receivedUpdate(QPair<Unsigned32, RC090Packet> value)
{
//    qDebug() << "received update for" << BBId::asString(value.first);
    QMutexLocker locker(&_receivedUpdatesMutex);

    _receivedUpdates[value.first] = value.second;
}

ParameterMap ParameterData::update()
{
    _receivedUpdatesMutex.lock();
    ParameterMap updatedValues(_receivedUpdates);
    _receivedUpdates.clear();
    _receivedUpdatesMutex.unlock();

//    qDebug() << "nb of values to be updated:" << updatedValues.size();

    ParameterMap changedValues;

    QWriteLocker wlocker(&_lastReceivedValuesLock);
    for(auto& id : updatedValues.keys())
    {
        if(updatedValues[id].data.size() != 0)
        {
            if(_lastReceivedValues.keys().contains(id))
            {
                if(_lastReceivedValues[id].data != updatedValues[id].data)
                {
                    _lastReceivedValues[id] = updatedValues[id];
                    changedValues[id] = updatedValues[id];
//                    qDebug() << "Received changed value for" << BBId::asString(id);
//                    qDebug() << "ModifyCode:" << updatedValues[id].modifyCode << "RequestType:" << updatedValues[id].requestType;
                }
            }
            else
            {
                _lastReceivedValues[id] = updatedValues[id];
                changedValues[id] = updatedValues[id];
//                qDebug() << "Received changed value for" << BBId::asString(id);
//                qDebug() << "ModifyCode:" << updatedValues[id].modifyCode << "RequestType:" << updatedValues[id].requestType;
            }

        }
        else
        {
            // normal in case we have a packet containing requestType modifyReply
            if(updatedValues[id].requestType == RequestType::ModifyReply)
            {
                if(updatedValues[id].modifyCode != ModifyCode::Success)
                {
                    qDebug() << "Modify failed for" << BBId::asString(id) << "reason:" << updatedValues[id].modifyCode;
                }
            }
            else
            {
                qDebug() << "Received invalid packet for" << BBId::asString(id);
                qDebug() << "ModifyCode:" << updatedValues[id].modifyCode << "RequestType:" << updatedValues[id].requestType;
            }
            // TODO: There's probably a message in this packet -> notify global events to show msg
        }
    }

//    qDebug() << "nb of changed values:" << changedValues.size();

    return changedValues;
}
