#pragma once
#include <QObject>
#include <QList>
#include <QVariant>
#include <QDebug>
#include <QVector2D>
#include <QDebug>
#include <QDateTime>
#include "PicanolTypes.h"
#include "BBId.h"
#include "RC90Values.h"
#include "Communicator.h"
#include "CommunicatorClientBase.h"

class Parameter : public CommunicatorClientBase
{
public:
    Parameter() {}  // TODO: temp for size debugging -> move to private again
    Parameter(Unsigned32 vgsid, UpdateFrequency::Enum updateFreq = UpdateFrequency::Medium, QObject* parent = NULL) :
        CommunicatorClientBase(parent),
        _vgsid(vgsid),
        _decimals(0),
        _updateFreq(updateFreq)
    {
        qDebug() << "Parameter::Parameter(). Size:" << sizeof(*this);
    }

    ~Parameter()
    {
        qDebug() << "~Parameter()";
        unRegisterId(_vgsid);
    }

    Q_OBJECT  // Adds only functions, so the overhead is limited

    Q_PROPERTY(float value READ value WRITE setValue NOTIFY valueChanged)
    Q_PROPERTY(QVector2D valueTP READ valueTP WRITE setValueTP NOTIFY valueChanged)
    Q_PROPERTY(QString valueStr READ valueStr WRITE setValueStr NOTIFY valueChanged)
    Q_PROPERTY(QDateTime valueDate READ valueDate WRITE setValueDate NOTIFY valueChanged)
    Q_PROPERTY(bool valueBool READ valueBool WRITE setValueBool NOTIFY valueChanged)
    Q_PROPERTY(QList<int> enums READ enums NOTIFY valueChanged)  // read only: gives the options, use float to get/set actual value

    Q_PROPERTY(int decimals READ decimals NOTIFY decimalsChanged)

signals:
    void valueChanged();
    void decimalsChanged();

public:
    float value()
    {
        return getRC90Value();
    }
    void setValue(float value) { setRC90Value(value); }

    QVector2D valueTP()
    {
        TimingPair tp = getRC90Value();
        QVector2D ret(tp.first, tp.second);
        qDebug() << "x:" << ret.x() << ", y:" << ret.y();
        return ret;
    }

    void setValueTP(QVector2D valueTP)
    {
        TimingPair tp(valueTP.x(), valueTP.y());
        setRC90Value(tp);
    }

    QString valueStr()
    {
        return getRC90Value().getValueAsQString();
    }

    void setValueStr(QString valueStr)
    {
        // TODO: wat als iemand een float als string wil doorsturen?
        setRC90Value(RC90Value(valueStr));
    }

    QDateTime valueDate()
    {
        PicanolTime dt = getRC90Value();
        return dt.dateTime;
    }

    void setValueDate(QDateTime valueDate)
    {
        // TODO: wat als iemand een float als string wil doorsturen?
        setRC90Value(PicanolTime(valueDate));
    }

    bool valueBool()
    {
        return getRC90Value();
    }

    void setValueBool(bool valueBool)
    {
        // TODO: wat als iemand een float als string wil doorsturen?
        setRC90Value(valueBool);
    }

    QList<int> enums()
    {
        QList<int> enums;
        try
        {
            QVector<RC90Value> possibleEnums(getRC90Values().getAllPossibleEnums());
            for(auto& val : possibleEnums)
            {
                enums.append((int)val);
            }
        }
        catch(...)
        {
            qDebug() << "Failed to get enums for" << BBId::asString(_vgsid);
        }
        return enums;
    }

    int decimals()
    {
        return _decimals;
    }

    virtual void updateIds(QMap<Unsigned32, RC90Value> changedIds)
    {
        if(changedIds.keys().contains(_vgsid))
        {
            setDecimals(changedIds[_vgsid].getPropertyDataType());
            emit valueChanged();
        }
    }

private:
    void setRC90Value(const RC90Value& val)
    {
        setId(_vgsid, val);
    }

    RC90Value getRC90Value()
    {
        registerId(_vgsid, _updateFreq);
        return getValue(_vgsid);
    }

    RC90Values getRC90Values()
    {
        registerId(_vgsid, _updateFreq);
        return getValues(_vgsid);
    }

    void setDecimals(PropertyDataType::Enum dataType)
    {
        int decimals = 0;
        if(dataType == PropertyDataType::Float || dataType == PropertyDataType::Double)
        {
            decimals = 3;
        }
        if(_decimals != decimals)
        {
            _decimals = decimals;
            emit decimalsChanged();
        }
    }


private:

    Parameter(const Parameter & other);
    Parameter& operator=(const Parameter& other);


private:
    Unsigned32 _vgsid;
    int _decimals;
    UpdateFrequency::Enum _updateFreq;

};
