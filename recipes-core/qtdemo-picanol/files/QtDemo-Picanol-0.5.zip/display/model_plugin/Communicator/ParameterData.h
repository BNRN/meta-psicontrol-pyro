#pragma once
#include <QMutex>
#include <QReadWriteLock>
#include <QMap>
#include <QPair>
#include "PicanolTypes.h"
#include "RC90Packet.h"
#include "RC90Value.h"

typedef QMap<Unsigned32, RC090Packet> ParameterMap;

class ParameterData
{

public:
    ParameterData();

    RC90Value getValue(Unsigned32 vgsid);
    ParameterMap update();

    void receivedUpdate(QPair<Unsigned32, RC090Packet> value);
    bool getLastRCPacket(Unsigned32 vgsid, RC090Packet& lastPacket);

private:
    ParameterMap _lastReceivedValues;
    ParameterMap _receivedUpdates;
    QMutex _receivedUpdatesMutex;
    QReadWriteLock _lastReceivedValuesLock;
};
