#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "../model_plugin/Global/GlobalVariables.h"
#include <QDebug>
#include <string>

//#include "../../parameter_puller/ParameterPuller.h"

int main(int argc, char *argv[])
{

//    for(int i = 0; i < argc; ++i)
//        qDebug() << i << ": " << argv[i];

//    if(argc > 1)
//    {
//        if(std::string(argv[1]) == "file")
//        {
//            qDebug() << "Using file RC Client";
//            GlobalVariables::USE_RC_FILE = true;
//        }
//        else
//        {
//            qDebug() << "Using Ip address: " << argv[1];
//            GlobalVariables::IP_ADDRESS = std::string(argv[1]);
//        }
//    }

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/DefineRcConfiguration.qml")));


//   ParameterPuller parameterPuller;
//   parameterPuller.runForever();

    return app.exec();
}
