#pragma once
#include <QString>
#include <sstream>
#include <iostream>
#include <string>
#include "../datatypes/PicanolTypes.h"


class BBId
{
public:
    static Unsigned32 encode(Unsigned16 baseId, Unsigned8 value1, Unsigned8 value2)
    {
        // -------------------------------------------------------------------------------------------
        // 31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 | 15 14 13 12 11 10 9 | 8 7 6 5 4 3 2 1 0 -
        // -------------------------------------------------------------------------------------------
        // -                    baseId                     |        value 1      |      value2       -
        // -------------------------------------------------------------------------------------------
        return (Unsigned32)((((Unsigned32)baseId) << 16) | (Unsigned16)((((Unsigned16)value1) << 8) | ((Unsigned8)value2)));
    }

    static Unsigned32 createId(Unsigned16 id)
    {
        return encode(id, 0, 0);
    }

    static Unsigned32 createIdChannel(Unsigned16 id, Unsigned8 channel)
    {
        return encode(id, channel, 0);
    }

    static Unsigned32 createIdIndex(Unsigned16 id, Unsigned8 index)
    {
        return encode(id, 0, index);
    }

    static Unsigned32 createIdChannelValve(Unsigned16 id, Unsigned8 channel, Unsigned8 index)
    {
        return encode(id, channel, index);
    }

    static Unsigned32 createIdChannelIndex(Unsigned16 id, Unsigned8 channel, Unsigned8 index)
    {
        return encode(id, channel, index);
    }

    static Unsigned32 createIdIndexIndex(Unsigned16 id, Unsigned8 index1, Unsigned8 index2)
    {
        return encode(id, index1, index2);
    }

    static Unsigned32 createIdIndex16(Unsigned16 id, Unsigned16 index)
    {
        // -----------------------------------------------------------------------------------------
        // 31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 | 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0 -
        // -----------------------------------------------------------------------------------------
        // -                    baseId                     |                  index                -
        // -----------------------------------------------------------------------------------------
        return (Unsigned32)((((Unsigned32)id) << 16) | index);
    }

    static Unsigned16 getBaseId(Unsigned32 value) { return (Unsigned16)(value >> 16); }
    static Unsigned8 getIndex1(Unsigned32 value) { return (Unsigned8)(value >> 8); }
    static Unsigned8 getIndex2(Unsigned32 value) { return (Unsigned8)(value); }

    static QString asString(Unsigned32 value)
    {
        std::stringstream ss;
        ss << getBaseId(value) << " - " << (Unsigned16)getIndex1(value) << " - " << (Unsigned16)getIndex2(value);
        std::string str(ss.str());
        return QString::fromStdString(str);
    }

};

