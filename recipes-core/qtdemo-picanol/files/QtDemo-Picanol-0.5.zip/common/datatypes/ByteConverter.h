#pragma once

#include "PicanolTypes.h"
#include "PicanolTime.h"
#include "converstionexceptions.h"
#include <QtEndian>
#include <string>
#include <sstream>

class ByteConverter
{

public:

// Values to binary data
    static ByteArray toDataBytes(Unsigned64 value)
    {
        ByteArray ret;
        ret.reserve(8);
        union {
            Unsigned8 c[8];
            Unsigned64 u64;
        } val;
        val.u64 = qToBigEndian(value);

        for(int i = 0; i < 8; ++i)
            ret.push_back(val.c[i]);

        return ret;
    };

    static ByteArray toDataBytes(Signed64 value)
    {
        union {
            Unsigned64 u;
            Signed64 s;
        } val;
        val.s = value;
        return toDataBytes(val.u);
    };

    static ByteArray toDataBytes(double value)
    {
        union {
            Unsigned64 u;
            double d;
        } val;
        val.d = value;
        return toDataBytes(val.u);
    };

    static ByteArray toDataBytes(Unsigned32 value)
    {
        ByteArray ret;
        ret.reserve(4);
        union {
            Unsigned8 c[4];
            Unsigned32 u32;
        } val;
        val.u32 = qToBigEndian(value);
        for(int i = 0; i < 4 ; ++i)
            ret.push_back(val.c[i]);
        return ret;
    };

    static ByteArray toDataBytes(Signed32 value)
    {
        union {
            Unsigned32 u;
            Signed32 s;
        } val;
        val.s = value;
        return toDataBytes(val.u);
    };

    static ByteArray toDataBytes(float value)
    {
        union {
            Unsigned32 u;
            float f;
        } val;
        val.f = value;
        return toDataBytes(val.u);
    };

    static ByteArray toDataBytes(Unsigned16 value)
    {
        ByteArray ret;
        union {
            Unsigned8 c[2];
            Unsigned16 u16;
        } val;
        val.u16 = qToBigEndian(value);
        for(int i = 0; i < 2 ; ++i)
            ret.push_back(val.c[i]);
        return ret;
    };

    static ByteArray toDataBytes(Signed16 value)
    {
        union {
            Unsigned16 u;
            Signed16 s;
        } val;
        val.s = value;
        return toDataBytes(val.u);
    };

    static ByteArray toDataBytes(bool value)
    {
        ByteArray ret;
        ret.push_back(value ? 1 : 0);
        return ret;
    };

    static ByteArray toDataBytes(Signed8 value)
    {
        ByteArray ret;
        ret.push_back(value);
        return ret;
    };

    static ByteArray toDataBytes(Unsigned8 value)
    {
        ByteArray ret;
        ret.push_back(value);
        return ret;
    };

    static ByteArray toDataBytes(const std::string& value)
    {
        // NOTE: QStrings contains 16bit characters as oposed to std::strings!!
        ByteArray byteArray;
        for (const auto& i : value)
        {
            byteArray.push_back(value[i]);
        }
        // TODO: find out whether to push back \0 as well
        return byteArray;
    }

    static ByteArray toDataBytes(TimingPair value)
    {
        // first 4 bytes are 'on' value
        // second 4 bytes are 'off' value
        ByteArray byteArray = toDataBytes(value.first);
        byteArray.append(toDataBytes(value.second));
        return byteArray;
    }

    static ByteArray toDataBytes(PicanolTime value)
    {
        // YYMD HMSW
        ByteArray byteArray;
        byteArray.reserve(8);
        union {
            Unsigned8 u8[2];
            Unsigned16 u16;
        } year;
        year.u16 = value.dateTime.date().year();
        byteArray.push_back(year.u8[1]);
        byteArray.push_back(year.u8[0]);
        byteArray.push_back((Unsigned8) value.dateTime.date().month());
        byteArray.push_back((Unsigned8) value.dateTime.date().day());
        byteArray.push_back((Unsigned8) value.dateTime.time().hour());
        byteArray.push_back((Unsigned8) value.dateTime.time().minute());
        byteArray.push_back((Unsigned8) value.dateTime.time().second());
        byteArray.push_back((Unsigned8) value.weekday);
        return byteArray;
    }

// Binary data to values

    static Unsigned8 getU8FromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 1)
            return data[position];
        throw InvalidDataLengthException();
    };

    static Unsigned8 getU8FromData(const QByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 1)
        {
            union {
                Unsigned8 u8;
                char c;
            } val;
            val.c = data.at(position);
            return val.u8;
        }
        throw InvalidDataLengthException();
    };

    static Signed8 getS8FromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 1)
            return data[position];
        throw InvalidDataLengthException();
    };

    static bool getBoolFromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 1)
            return data[position] == 0 ? false : true;
        throw InvalidDataLengthException();
    };

    static Unsigned32 getU64FromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 8)
        {
            union {
                Unsigned8 c[8];
                Unsigned64 u64;
            } val;
            for(int i = 0; i < 8 ; ++i)
                val.c[i] = data[position + i];
            return qFromBigEndian(val.u64);
        }
        throw InvalidDataLengthException();
    };

    static Unsigned32 getU32FromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 4)
        {
            union {
                Unsigned8 c[4];
                Unsigned32 u32;
            } val;
            for(int i = 0; i < 4 ; ++i)
                val.c[i] = data[position + i];
            return qFromBigEndian(val.u32);
        }
        throw InvalidDataLengthException();
    };

    static Unsigned32 getU32FromData(const QByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 4)
        {
            union {
                Unsigned8 c[4];
                Unsigned32 u32;
            } val;
            for(int i = 0; i < 4 ; ++i)
                val.c[i] = data[position + i];
            return qFromBigEndian(val.u32);
        }
        throw InvalidDataLengthException();
    };

    static Unsigned16 getU16FromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 2)
        {
            union {
                Unsigned8 c[2];
                Unsigned16 u16;
            } val;
            for(int i = 0; i < 2 ; ++i)
                val.c[i] = data[position + i];
            return qFromBigEndian(val.u16);
        }
        throw InvalidDataLengthException();
    };

    static Unsigned16 getU16FromData(const QByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 2)
        {
            union {
                Unsigned8 c[2];
                Unsigned16 u16;
            } val;
            for(int i = 0; i < 2 ; ++i)
                val.c[i] = data[position + i];
            return qFromBigEndian(val.u16);
        }
        throw InvalidDataLengthException();
    };

    static float getFloatFromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 4)
        {
            union {
                float f;
                Unsigned32 u32;
            } val;
            val.u32 = getU32FromData(data, position);
            return val.f;
        }
        throw InvalidDataLengthException();
    }

    static float getDoubleFromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 8)
        {
            union {
                double d;
                Unsigned64 u64;
            } val;
            val.u64 = getU64FromData(data, position);
            return val.d;
        }
        throw InvalidDataLengthException();
    }

    static std::string getStringFromData(const ByteArray& data, Unsigned32 position)
    {
        std::stringstream stream;
        bool nullTerminationDone = false;
        for(Unsigned32 i = position; i < data.size(); ++i)
        {
            stream << data[i];
            if(data[i] == 0)
            {
                nullTerminationDone = true;
                break;
            }
        }
        if(not nullTerminationDone)
            stream << 0;
        return stream.str();
    }

    static Signed64 getS64FromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 8)
        {
            union {
                Signed64 s64;
                Unsigned64 u64;
            } val;
            val.u64 = getU64FromData(data, position);
            return val.s64;
        }
        throw InvalidDataLengthException();
    };

    static Signed32 getS32FromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 4)
        {
            union {
                Signed32 s32;
                Unsigned32 u32;
            } val;
            val.u32 = getU32FromData(data, position);
            return val.s32;
        }
        throw InvalidDataLengthException();
    };

    static Signed16 getS16FromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 2)
        {
            union {
                Signed16 s16;
                Unsigned16 u16;
            } val;
            val.u16 = getU16FromData(data, position);
            return val.s16;
        }
        throw InvalidDataLengthException();
    };

    static TimingPair getTimingPairFromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 8)
        {
            TimingPair val;
            val.first = getFloatFromData(data, position);
            val.second = getFloatFromData(data, position + sizeof(float));
            return val;
        }
        throw InvalidDataLengthException();
    };

    static PicanolTime getPicanolTimeFromData(const ByteArray& data, Unsigned32 position)
    {
        if(data.size() >= position + 8)
        {
            ByteArray ba;
            ba.resize(8);
            for(Unsigned32 i = 0; i < 8; ++i)
                ba.push_back(data[position + i]);
            PicanolTime time(ba);
            return time;
        }
        throw InvalidDataLengthException();
    };
};
