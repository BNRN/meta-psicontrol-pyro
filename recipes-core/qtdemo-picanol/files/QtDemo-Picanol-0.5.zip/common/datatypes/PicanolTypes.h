#pragma once
#include <QPair>
#include <QVector>

typedef unsigned char               Unsigned8;  // use this as less as possible, in most cases no added value versus 'Unsigned16'.
typedef unsigned short              Unsigned16;
typedef unsigned int                Unsigned32;
typedef unsigned long long          Unsigned64;
typedef signed char                 Signed8;    // use this as less as possible, in most cases no added value versus 'Unsigned16'.
typedef signed short                Signed16;
typedef signed int                  Signed32;
typedef signed long long            Signed64;
typedef QVector<Unsigned8>          ByteArray;
typedef QPair<float, float>         TimingPair;

