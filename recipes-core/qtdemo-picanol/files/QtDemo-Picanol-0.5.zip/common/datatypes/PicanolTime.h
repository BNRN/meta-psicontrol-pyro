#pragma once
#include "PicanolTypes.h"
#include <QByteArray>
#include <QDateTime>
#include "../exceptions/converstionexceptions.h"

class PicanolTime
{
    enum WeekDay
    {
        Monday = 0,
        Tuesday = 1,
        Wednesday = 2,
        Thursday = 3,
        Friday = 4,
        Saturday = 5,
        Sunday = 6
    };

public:
    PicanolTime() : dateTime(QDateTime::currentDateTime()) {}

    PicanolTime(QDateTime datetime) : dateTime(datetime) {}

    PicanolTime(ByteArray array)
    {
        // a ByteArray as in an RC90Packet is YYMDhmsw
//        if(array.size() != 8)
//        {
//            throw InvalidDataLengthException();
//        }
        Unsigned16 year = (array[0] << 8) + array[1];
        QDate date(year, array[2], array[3]);
        QTime time(array[4], array[5], array[6]);
        dateTime = QDateTime(date, time);
        weekday = (WeekDay)array[7];
    }

    PicanolTime(Unsigned16 year, Unsigned8 month, Unsigned8 day, Unsigned8 hour, Unsigned8 minute, Unsigned8 second)
    {
        QDate date(year, month, day);
        QTime time(hour, minute, second);
        dateTime = QDateTime(date, time);
    }

    QString asString()
    {
        return dateTime.toString("yyyy MM dd - hh:mm:ss");
    }

    // public members
    QDateTime dateTime;
    WeekDay weekday;
};
