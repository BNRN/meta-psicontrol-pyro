#pragma once
#include <QString>

class RC90Exception
{
public:
    RC90Exception(const QString& what)
    {
        _whatHappend = what;
    }
    QString what() const throw()
    {
        return _whatHappend;
    }

private:
    QString _whatHappend;
};
