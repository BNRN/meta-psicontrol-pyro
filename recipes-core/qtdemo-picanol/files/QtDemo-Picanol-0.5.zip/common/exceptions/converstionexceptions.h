#pragma once
#include <QString>

class InvalidDataException
{
public:
    InvalidDataException(const QString& what)
    {
        _whatHappend = what;
    }

    QString what() const throw()
    {
        return _whatHappend;
    }

private:
    QString _whatHappend;
};

class InvalidDataTypeException : public InvalidDataException
{
public:
    InvalidDataTypeException(const QString& what) : InvalidDataException(what) {}
    InvalidDataTypeException(): InvalidDataException("Invalid data type.") {}

};


class InvalidDataFormatException : public InvalidDataException
{
public:
    InvalidDataFormatException(const QString& what) : InvalidDataException(what) {}
    InvalidDataFormatException(): InvalidDataException("Invalid data format.") {}
};

class InvalidDataLengthException : public InvalidDataException
{
public:
    InvalidDataLengthException(const QString& what) : InvalidDataException(what) {}
    InvalidDataLengthException(): InvalidDataException("Invalid data length.") {}
};
