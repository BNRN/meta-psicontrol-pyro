/*
 * RC90Values.cpp
 *
 *  Created on: 27 sep. 2017
 *      Author: slr
 */
#include "RC90Values.h"

#include "../exceptions/converstionexceptions.h"
#include "../exceptions/rcexception.h"
#include <algorithm>
#include <iostream>
#include <sstream>
#include <string>
#include <limits>

#include "../datatypes/ByteConverter.h"

RC90Values::RC90Values():
    _value(RC90Value(0)),
    _min(RC90Value(0)),
    _max(RC90Value(0)),
    _default(RC90Value(0)),
    _list(),
    _dataFormat(PropertyDataType::Unknown),
    _dataType(DataType::Unknown)
{
}

RC90Values::RC90Values(const RC090Packet& rc90packet) :
    _value(RC90Value(0)),
    _min(RC90Value(0)),
    _max(RC90Value(0)),
    _default(RC90Value(0)),
    _list(),
    _dataFormat(rc90packet.dataFormat),
    _dataType(rc90packet.dataType),
    _binaryData(rc90packet.data)
{
    switch(_dataType)
    {
    case DataType::Value:
    {
        // single value
        _value = _getRC90ValueAtIndex(0);
        _fillInMinAndMaxAccordingToType();
        break;
    }
    case DataType::Unknown:
    {
        throw RC90Exception("Cannot handle unknown data type.");
    }
    case DataType::Array:
    {
        Unsigned32 nbElements = _binaryData.size() / getBinarySizeOfDataFormat(_dataFormat);
        // allocate memory
        _list.reserve(nbElements);
        for(Unsigned32 i = 0; i < nbElements; ++i)
        {
            _list.push_back(_getRC90ValueAtIndex(i * getBinarySizeOfDataFormat(_dataFormat)));
        }
        break;
    }
    case DataType::Range:
    {
        _value = _getRC90ValueAtIndex(0);
        _default = _getRC90ValueAtIndex(getBinarySizeOfDataFormat(_dataFormat));
        _min = _getRC90ValueAtIndex(2 * getBinarySizeOfDataFormat(_dataFormat));
        _max = _getRC90ValueAtIndex(3 * getBinarySizeOfDataFormat(_dataFormat));
        break;
    }
    case DataType::Enumeration:
    {
        _value = _getRC90ValueAtIndex(0);
        _default = _getRC90ValueAtIndex(getBinarySizeOfDataFormat(PropertyDataType::Signed32));
        Unsigned32 nbElements = ByteConverter::getU16FromData(_binaryData, 4);
        // allocate sufficient memory in the vector
        _list.reserve(nbElements);
        for(Unsigned32 i = 0; i<nbElements; ++i)
        {
            Unsigned32 offset = 10;  // 4 bytes for actual value, 4 byte for default, 2 bytes for nbElements
            _list.push_back(_getRC90ValueAtIndex(offset + i * getBinarySizeOfDataFormat(PropertyDataType::Signed32)));
        }
        break;
    }
    }
}

void RC90Values::setValue(RC90Value& value)
{
    _value = value;
}

RC90Value RC90Values::getValue()
{
    if(_dataType != DataType::Array && _dataType != DataType::Unknown)
        return _value;

    throw InvalidDataTypeException("getValue not supported");
}
RC90Value RC90Values::getMin()
{
    if(_dataType != DataType::Array && _dataType != DataType::Unknown && _dataType != DataType::Enumeration)
        return _min;

    throw InvalidDataTypeException("getMin not supported");
}
RC90Value RC90Values::getMax()
{
    if(_dataType != DataType::Array && _dataType != DataType::Unknown && _dataType != DataType::Enumeration)
        return _max;

    throw InvalidDataTypeException("getMax not supported");
}
RC90Value RC90Values::getDefault()
{
    if(_dataType != DataType::Array && _dataType != DataType::Unknown)
        return _default;

    throw InvalidDataTypeException();
}

QVector<RC90Value> RC90Values::getAllPossibleEnums()
{
    if(_dataType == DataType::Enumeration)
        return _list;

    throw InvalidDataTypeException("getAllPossibleEnums not supported for non enum types");
}
QVector<RC90Value> RC90Values::getArray()
{
    if(_dataType == DataType::Array)
        return _list;

    throw InvalidDataTypeException("getArray not supported for non array data types");
}

PropertyDataType::Enum RC90Values::getDataFormat()
{
    return _dataFormat;
}
DataType::Enum RC90Values::getDataType()
{
    return _dataType;
}


RC90Value RC90Values::_getRC90ValueAtIndex(Unsigned32 index)
{
    try
    {
        switch(_dataFormat)
        {
        case PropertyDataType::Unknown:
        case PropertyDataType::Binary:
        case PropertyDataType::Rc060Password:
        case PropertyDataType::Message:
            return RC90Value(_binaryData, _dataFormat);
        case PropertyDataType::Bool:
            return RC90Value(ByteConverter::getBoolFromData(_binaryData, index));
        case PropertyDataType::Float:
            return RC90Value(ByteConverter::getFloatFromData(_binaryData, index));
        case PropertyDataType::Double:
            return RC90Value(ByteConverter::getDoubleFromData(_binaryData, index));
        case PropertyDataType::TimingPair:
            return RC90Value(ByteConverter::getTimingPairFromData(_binaryData, index));
        case PropertyDataType::Unsigned8:
            return RC90Value(ByteConverter::getU8FromData(_binaryData, index));
        case PropertyDataType::Unsigned16:
            return RC90Value(ByteConverter::getU16FromData(_binaryData, index));
        case PropertyDataType::Unsigned32:
            return RC90Value(ByteConverter::getU32FromData(_binaryData, index));
        case PropertyDataType::Unsigned64:
            return RC90Value(ByteConverter::getU64FromData(_binaryData, index));
        case PropertyDataType::Signed8:
            return RC90Value(ByteConverter::getS8FromData(_binaryData, index));
        case PropertyDataType::Signed16:
            return RC90Value(ByteConverter::getS16FromData(_binaryData, index));
        case PropertyDataType::Signed32:
            return RC90Value(ByteConverter::getS32FromData(_binaryData, index));
        case PropertyDataType::Signed64:
            return RC90Value(ByteConverter::getS64FromData(_binaryData, index));
        case PropertyDataType::String:
        case PropertyDataType::JsonString:
            return RC90Value(ByteConverter::getStringFromData(_binaryData, index));
        }
        throw InvalidDataTypeException();
    }
    catch ( ... )
    {
        throw RC90Exception("Failed to convert data at");
    }
}

Signed32 RC90Values::getBinarySizeOfDataFormat(PropertyDataType::Enum dataFormat)
{
    switch(dataFormat)
    {
    case PropertyDataType::Unknown:
    case PropertyDataType::Binary:
    case PropertyDataType::Rc060Password:
    case PropertyDataType::Message:
    case PropertyDataType::String:
    case PropertyDataType::JsonString:
        return -1;
    case PropertyDataType::Unsigned8:
    case PropertyDataType::Signed8:
        return 1;
    case PropertyDataType::Unsigned16:
    case PropertyDataType::Signed16:
        return 2;
    case PropertyDataType::Unsigned32:
    case PropertyDataType::Signed32:
    case PropertyDataType::Bool:
    case PropertyDataType::Float:
        return 4;
    case PropertyDataType::Unsigned64:
    case PropertyDataType::Signed64:
    case PropertyDataType::Double:
    case PropertyDataType::TimingPair:
    case PropertyDataType::PsiTime:
        return 8;
    }
    throw InvalidDataTypeException();
}

void RC90Values::_fillInMinAndMaxAccordingToType()
{
    switch(_dataFormat)
    {
    case PropertyDataType::Unknown:
    case PropertyDataType::Binary:
    case PropertyDataType::Rc060Password:
    case PropertyDataType::Message:
    case PropertyDataType::String:
    case PropertyDataType::JsonString:
    case PropertyDataType::TimingPair:
    case PropertyDataType::PsiTime:
        // don't do anything
        break;
    case PropertyDataType::Bool:
        _min = std::numeric_limits<bool>::min();
        _max = std::numeric_limits<bool>::max();
        break;
    case PropertyDataType::Float:
        _min = std::numeric_limits<float>::min();
        _max = std::numeric_limits<float>::max();
        break;
    case PropertyDataType::Double:
        _min = std::numeric_limits<double>::min();
        _max = std::numeric_limits<double>::max();
        break;
    case PropertyDataType::Unsigned8:
        _min = std::numeric_limits<Unsigned8>::min();
        _max = std::numeric_limits<Unsigned8>::max();
        break;
    case PropertyDataType::Unsigned16:
        _min = std::numeric_limits<Unsigned16>::min();
        _max = std::numeric_limits<Unsigned16>::max();
        break;
    case PropertyDataType::Unsigned32:
        _min = std::numeric_limits<Unsigned32>::min();
        _max = std::numeric_limits<Unsigned32>::max();
        break;
    case PropertyDataType::Unsigned64:
        _min = std::numeric_limits<Unsigned64>::min();
        _max = std::numeric_limits<Unsigned64>::max();
        break;
    case PropertyDataType::Signed8:
        _min = std::numeric_limits<Signed8>::min();
        _max = std::numeric_limits<Signed8>::max();
        break;
    case PropertyDataType::Signed16:
        _min = std::numeric_limits<Signed16>::min();
        _max = std::numeric_limits<Signed16>::max();
        break;
    case PropertyDataType::Signed32:
        _min = std::numeric_limits<Signed32>::min();
        _max = std::numeric_limits<Signed32>::max();
        break;
    case PropertyDataType::Signed64:
        _min = std::numeric_limits<Signed64>::min();
        _max = std::numeric_limits<Signed64>::max();
        break;

    }
}
