#pragma once

#include <string>
#include <QUdpSocket>
#include "RC90BaseClient.h"
#include "RC90Serializer.h"

class RC90Client : public RC90BaseClient
{
    Q_OBJECT


public:
    RC90Client(std::string target, int port, bool sync);
    ~RC90Client();

    virtual RC090Packet sendSync(RC090Packet& packet, Unsigned32 msTimeout = 100);
    virtual void sendAsync(RC090Packet& packet);

private:
    RC090Packet _receiveSync(Unsigned32 msTimeout);
    RC090Packet _receiveFragments(RC090Packet firstFragment, Unsigned32 msTimeout);


public slots:
    void readPendingDatagrams();

//signals:
//    void receivedRCPacket(RC090Packet rcPacket);

private:

    std::string _ip;
    int         _port;
    QUdpSocket  _udpSocket;
    Unsigned8   _cookie;
    bool        _sync;

    QMap<Unsigned32, Unsigned8> _lastRequestCookieMap;
};

