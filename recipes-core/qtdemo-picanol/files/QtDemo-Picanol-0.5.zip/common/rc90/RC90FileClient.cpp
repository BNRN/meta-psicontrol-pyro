#include "RC90FileClient.h"
#include "rcexception.h"
#include <QTextStream>
#include "RC90Serializer.h"
#include <QString>
#include <QDebug>
#include <QFileInfo>
#include <QMutexLocker>



RC90FileClient::RC90FileClient(const QString& file, bool debugMode) :
    RC90BaseClient(),
    _debugMode(debugMode),
    _file(file),
    _lock()
{
    if(not _debugMode)
    {
        _packetsInMemory = _readFromFile();
    }
}

RC90FileClient::~RC90FileClient()
{

    qDebug() << "Enter RC90FileClient::~RC90FileClient()";
    if(not _debugMode)
    {
        _writeToFile(_packetsInMemory);
    }
}

RC090Packet RC90FileClient::sendSync(RC090Packet& packet, Unsigned32 msTimeout)
{
    if(packet.requestType == RequestType::Request)
        return _handleRequest(packet);
    else if(packet.requestType == RequestType::Modify)
        return _handleModify(packet);
    else
        throw RC90Exception("Invalid request type.");
}

RC090Packet RC90FileClient::_handleRequest(const RC090Packet& packet)
{
    QMutexLocker locker(&_lock);
    for(auto& packetInMemory : _packetsInMemory)
    {
        if(packet.vgsId == packetInMemory.vgsId)
            return packetInMemory;
    }
    throw RC90Exception("Id not found.");
}

RC090Packet RC90FileClient::_handleModify(const RC090Packet& packet)
{
    QMutexLocker locker(&_lock);

    for(auto& packetInMemory : _packetsInMemory)  // by taking ref, _packetsInMemory is updated as well
    {
        if(packet.vgsId == packetInMemory.vgsId)
        {
            if(packet.dataType == DataType::Value || packet.dataType == DataType::Range
                    || packet.dataType == DataType::Enumeration)
            {
                ByteArray newValue = packet.data;
                for(Unsigned32 i = 0; i < newValue.size(); ++i)
                {
                    packetInMemory.data[i] = newValue[i];
                }
                return packetInMemory;
            }
            else
            {
                throw RC90Exception("Modify of DataType Unknown or Array not supported in RCFileClient.");
            }
        }
    }
    throw RC90Exception("Id not found.");

}

void RC90FileClient::sendAsync(RC090Packet& packet)
{
    // No reason to implement this...
}

void RC90FileClient::saveFile()
{
    qDebug() << "saving file";
    _lock.lock();
    QList<RC090Packet> copy(_packetsInMemory);
    _lock.unlock();
    _writeToFile(copy);
}

void RC90FileClient::_writeToFile(const QList<RC090Packet>& rc90packets)
{
//    qDebug() << QFileInfo(_file).absoluteFilePath();
    if(_file.open(QIODevice::WriteOnly))
    {
        for(const auto& packet : rc90packets)
        {
            QByteArray writeArray = RC90Serializer::serialize(packet);
//            qDebug() << "original size" << writeArray.size();
            writeArray = writeArray.toHex();
//            qDebug() << "toHex size" << writeArray.size();
            writeArray.append('\n');
//            qDebug() << writeArray;
            _file.write(writeArray);
        }
        _file.close();
    }
    else
    {
        qDebug() << "Failed to open file.";
    }
}

QList<RC090Packet> RC90FileClient::_readFromFile()
{
    qDebug() << "start reading from" << QFileInfo(_file).absoluteFilePath();
    QList<RC090Packet> rc90packets;
    if(_file.open(QIODevice::ReadOnly))
    {
        Unsigned32 i = 0;
        while(not _file.atEnd())
        {
            QByteArray readArray;
            try
            {
                readArray = _file.readLine();
//                qDebug() << readArray;
            }
            catch(...)
            {
                qDebug() << "Failed to read line" <<i;
            }
            try
            {
                if(readArray.size() != 0)
                    rc90packets.push_back(RC90Serializer::deserialize(QByteArray::fromHex(readArray)));
            }
            catch(...)
            {
                qDebug() << "Failed to parse line" <<i;
            }
            i++;
        }
        _file.close();
    }
    else
    {
        qDebug() << "Failed to open file.";
    }

    return rc90packets;
}

