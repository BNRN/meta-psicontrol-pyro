#include "RC90Tester.h"
#include "../datatypes/BBId.h"
#include "../datatypes/VGSSettingsId.h"
#include "../exceptions/rcexception.h"

RC90Tester::RC90Tester():
    _rc90udpClient("10.0.182.228", 9060, true),
    _rc90fileClient("allIdfile.rc", true /*debugMode*/)
{
}

void RC90Tester::tryFragments()
{
    for(Unsigned8 i1 = 0; i1 < 255; ++i1)
    {
        for(Unsigned8 i2 = 0; i2 < 255; ++i2)
        {
            RC090Packet request = RC090Packet::createRequest(BBId::createIdChannelIndex(4412, i1, i2));
            RC090Packet answer;
            try
            {
                _tryRequest(request, answer);
            }
            catch(...)
            {
                qDebug() << "error at i1:" << i1 << ", i2:" << i2;
                return;
            }
        }
    }

}

void RC90Tester::tryAllIds()
{
    QSet<Unsigned32> skipList;
    skipList.insert(4412);
    skipList.insert(4413);
    skipList.insert(4414);


    QList<RC090Packet> packets;
    for(Unsigned16 id = 0; id < 6000; ++id)
    {
        qDebug() << "Starting on id" << id;

//        if(id >= 4212 && id <= 4214)
//        {
//            qDebug() << "skipping id" << id;
//            break;
//        }

        if(skipList.contains(id))
        {
            qDebug() << "skipping id" << id;
            continue;
        }

        bool hasId = false;
        bool hasIndex1 = false;
        bool hasIndex2 = false;

        // check if any id exists:
        RC090Packet answer;
        RC090Packet request = RC090Packet::createRequest(BBId::createId(id));
        hasId = _tryRequest(request, answer);
        if(hasId)
            packets.push_back(answer);

        if(hasId)
        {
            // check if it has index1:
            for(Unsigned8 index1 = 1; index1 < 50; ++index1)
            {
                RC090Packet request = RC090Packet::createRequest(BBId::createIdChannel(id, index1));
                bool success = _tryRequest(request, answer);
                if(success)
                {
                    hasIndex1 = true;
                    packets.push_back(answer);
                }
                else
                    break;  // no (or no more) ids with increasing index1

            }

            // check if it has index2:
            for(Unsigned8 index2 = 1; index2 < 50; ++index2)
            {
                RC090Packet request = RC090Packet::createRequest(BBId::createIdIndex(id, index2));
                bool success = _tryRequest(request, answer);
                if(success)
                {
                    hasIndex2 = true;
                    packets.push_back(answer);
                }
                else
                    break;  // no (or no more) ids with increasing index1

            }

            // if we have both index1 and index2: check for combinations
            if(hasIndex1 && hasIndex2)
            {
                for(Unsigned8 index1 = 1; index1 < 50; ++index1)
                {
                    bool hasAtLeast1Index2 = false;
                    for(Unsigned8 index2 = 1; index2 < 50; ++index2)
                    {
                        RC090Packet request = RC090Packet::createRequest(BBId::createIdChannelIndex(id, index1, index2));
                        bool success = _tryRequest(request, answer);
                        if(success)
                        {
                            hasAtLeast1Index2 = true;
                            packets.push_back(answer);
                        }
                        else
                        {
                            break;  // no (or no more) ids with increasing index2
                        }
                    }
                    if(not hasAtLeast1Index2)
                    {
                        // if no success for any index2 -> means no more index1 either
                        break;
                    }
                }
            }
        }
        qDebug() << "id" << id << "has id:" << hasId << "has index1:" << hasIndex1 << "has index2:" << hasIndex2;
    }


    qDebug() << "starting write to file";
    try
    {
        _rc90fileClient._writeToFile(packets);
        qDebug() << "wrote data to file";
    }
    catch(...)
    {
        qDebug() << "Failed to write to file";
    }

}

bool RC90Tester::_tryRequest(RC090Packet& request, RC090Packet& answer)
{
    Unsigned32 retries = 2;
    do
    {
        try
        {
            answer = _rc90udpClient.sendSync(request);
            if(answer.modifyCode == ModifyCode::Success)
                return true;
            return false;  // invalid
//                qDebug() << "received data from machine";
            break;  // auto of do while
        }
        catch (const RC90Exception& e)
        {
            qDebug() << "RC90 exception" << e.what();
            if(retries > 0)
                --retries;
        }
    } while (retries > 0);
    return false;  // no communication
}

void RC90Tester::testInvalidId()
{
    Unsigned32 id = BBId::createId(VGS_ID_RAPIER_FILLING_DETECTION_VALUE);  // does not exist on air
    Unsigned32 retries = 2;
    do
    {
        try
        {
            RC090Packet sendPacket = RC090Packet::createRequest(id);
            RC090Packet receivedPacket = _rc90udpClient.sendSync(sendPacket);
            qDebug() << receivedPacket.dataFormat;
            qDebug() << receivedPacket.dataType;
            qDebug() << receivedPacket.modifyCode;
//                qDebug() << "received data from machine";
            break;  // auto of do while
        }
        catch (const RC90Exception& e)
        {
            qDebug() << "RC90 exception" << e.what();
            if(retries > 0)
                --retries;
        }
    } while (retries > 0);
}

void RC90Tester::test()
{
    Unsigned8 nbChannels = 6;
    Unsigned8 nbRvs = 26;
    QList<Unsigned32> ids;
    for(Unsigned8 ch = 0; ch < nbChannels; ++ch)
    {
        // HB
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_MIF_FMV_TIMING_DEG_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_MIF_FMV_TIMING_MS_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_MMV_TIMING_DEG_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_MMV_TIMING_MS_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_TMV_TIMING_DEG_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_TMV_TIMING_MS_ACTUAL, ch));

        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_PRESSUREREGULATOR_CH_X_PRESSURE, ch));

        // SN
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_SN_TIMING_DEG_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_SN_TIMING_MS_ACTUAL, ch));

        // RV
        for(Unsigned8 rv = 0; rv < nbRvs; ++rv)
        {
            ids.push_back(BBId::createIdChannelValve(VGS_ID_ISYS_CH_X_RV_X_TIMING_DEG_ACTUAL, ch, rv));
            ids.push_back(BBId::createIdChannelValve(VGS_ID_ISYS_CH_X_RV_X_TIMING_MS_ACTUAL, ch, rv));
            ids.push_back(BBId::createIdChannelValve(VGS_ID_ISYS_CH_X_RV_X_TIMING_DEG_UNOPTIMIZED, ch, rv));
        }

        // PFT
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_PFT_MODE, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_PA_EXP_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_PFT_BRAKE_DEG_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_PFT_STRETCH_DEG_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_P_START_ACTUAL, ch));
        ids.push_back(BBId::createIdChannel(VGS_ID_ISYS_CH_X_CUTTING_POSITION, ch));
    }

    for(Unsigned8 rv = 0; rv < nbRvs; ++rv)
    {
        ids.push_back(BBId::createIdIndex(VGS_ID_ISYS_RV_X_NOZZLES, rv));
        ids.push_back(BBId::createIdIndex(VGS_ID_ISYS_RV_X_DISTANCE , rv));
    }

    ids.push_back(BBId::createId(VGS_ID_ISYS_RN_SHED_ENTRY));
    ids.push_back(BBId::createId(VGS_ID_CROSSING_POSITION));
    ids.push_back(BBId::createId(VGS_ID_MACHINE_POSITION));
    ids.push_back(BBId::createId(VGS_ID_CORRECTION_FACTOR));
    ids.push_back(BBId::createId(VGS_ID_REQUESTED_MACHINE_SPEED));

    ids.push_back(BBId::createIdIndex(VGS_ID_ISYS_PRESSUREREGULATOR_RELAY_X_PRESSURE, 0));
    ids.push_back(BBId::createIdIndex(VGS_ID_ISYS_PRESSUREREGULATOR_RELAY_X_PRESSURE, 1));

    ids.push_back(BBId::createId(VGS_ID_SYSTEM_DATE_AND_TIME));

    QList<RC090Packet> packets;
    for(auto& id : ids)
    {
        Unsigned32 retries = 2;
        do
        {
            try
            {
                RC090Packet sendPacket = RC090Packet::createRequest(id);
                packets.push_back(_rc90udpClient.sendSync(sendPacket));
//                qDebug() << "received data from machine";
                break;  // auto of do while
            }
            catch (const RC90Exception& e)
            {
                qDebug() << "RC90 exception" << e.what();
                --retries;
            }
        } while (retries > 0);

    }
//    qDebug() << "packet size:" << packets.size();


    try
    {
        _rc90fileClient._writeToFile(packets);
        qDebug() << "wrote data to file";
    }
    catch(...)
    {
        qDebug() << "Failed to write to file";
    }


    try
    {
        QList<RC090Packet> readPackets = _rc90fileClient._readFromFile();
        qDebug() << "Read data from file";
        for(auto& packet : readPackets)
        {
            qDebug() << BBId::getBaseId(packet.vgsId);
        }
    }
    catch(...)
    {
        qDebug() << "Failed to read from file";
    }


}
