/*
 * RC90Values.h
 *
 *  Created on: 27 sep. 2017
 *      Author: slr
 */

#pragma once
#include <QVector>

#include "RC90Packet.h"
#include "RC90Value.h"

class RC90Values
{
public:
    RC90Values();
    RC90Values(const RC090Packet& rc90packet);

    void setValue(RC90Value& value);  // temp

    RC90Value getValue();
    RC90Value getMin();
    RC90Value getMax();
    RC90Value getDefault();

    PropertyDataType::Enum getDataFormat();
    DataType::Enum getDataType();

    QVector<RC90Value> getAllPossibleEnums();
    QVector<RC90Value> getArray();

    static Signed32 getBinarySizeOfDataFormat(PropertyDataType::Enum dataFormat);

private:
    RC90Value _getRC90ValueAtIndex(Unsigned32 index);
    void _fillInMinAndMaxAccordingToType();

private:
    RC90Value _value;
    RC90Value _min;
    RC90Value _max;
    RC90Value _default;
    QVector<RC90Value> _list;

    PropertyDataType::Enum _dataFormat;
    DataType::Enum _dataType;
    ByteArray _binaryData;

};
