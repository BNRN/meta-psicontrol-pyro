#include "RC90Client.h"
#include "rcexception.h"
#include "../datatypes/BBId.h"
#include <QtEndian>
//#include <QNetworkDatagram>
#include <QElapsedTimer>
#include <QThread>

#include <sys/types.h>
#include <cstdio>
#include <iostream>

RC90Client::RC90Client(std::string target, int port, bool sync) :
    RC90BaseClient(NULL),
    _ip(target),
    _port(port),
    _udpSocket(this),
    _cookie(0),
    _sync(sync)
{
    qDebug() << "before bind";
    _udpSocket.bind();
    qDebug() << "after bind";
    if(not _sync)
    {
        connect(&_udpSocket, &QUdpSocket::readyRead, this, &RC90Client::readPendingDatagrams);
    }

}

RC90Client::~RC90Client()
{
    if(not _sync)
    {
        disconnect(&_udpSocket, &QUdpSocket::readyRead, this, &RC90Client::readPendingDatagrams);
    }
}

//void RC90Client::readyRead()
//{

//}

void RC90Client::readPendingDatagrams()
{
    while(_udpSocket.hasPendingDatagrams())
    {
       // QByteArray datagram = _udpSocket.receiveDatagram().data();
        QByteArray datagram;
        datagram.resize(_udpSocket.pendingDatagramSize());
        QHostAddress sender;
        quint16 senderPort;

        _udpSocket.readDatagram(datagram.data(), datagram.size(),
                                &sender, &senderPort);

//        // convert QByteArray to Unsinged8*
//        Unsigned32 size = datagram.size();
//        Unsigned8* buffer = new Unsigned8[size];  // TODO: deserializer must work with QByteArray
//        for(Unsigned32 i = 0; i < size; ++i)
//        {
//            *(buffer + i) = datagram[i];
//        }
//        RC090Packet reply = RC90Serializer::deserialize(buffer, size);
//        // we have copied the content in the deserializer -> we don't need the buffer anymore
//        delete buffer;  // this is ugly, but temporary...

        RC090Packet reply = RC90Serializer::deserialize(datagram);

        qDebug() << "Got an answer for id " << BBId::getBaseId(reply.vgsId);
        // TODO: fragments

        // check if the answer cookie correponds with the last request cookie
        if(_lastRequestCookieMap.contains(reply.vgsId) && _lastRequestCookieMap[reply.vgsId] == reply.cookie)
        {
            emit receivedRCPacket(reply);
        }
        else
        {
            qDebug() << "received old or non requested packet for id" << BBId::getBaseId(reply.vgsId);
        }


    }
}

void RC90Client::sendAsync(RC090Packet& packet)
{
    packet.cookie = _cookie;
    _lastRequestCookieMap[packet.vgsId] = _cookie;  // creates if not in the map, overwrites if in the map
    _cookie++;  // will automatically overflow and restart from zero

//    Unsigned32 length = packet.fullPacketLength;
//    //std::cout << "ready for send." << std::endl;

//    Unsigned8* buffer = new Unsigned8[1024];

//    buffer = RC90Serializer::serialize(packet, buffer, 1024);

//    QByteArray byteArray;
//    for(Unsigned32 i = 0; i < length; ++i)
//        byteArray.push_back(buffer[i]);
//    delete buffer;
    QByteArray byteArray = RC90Serializer::serialize(packet);
    _udpSocket.writeDatagram(byteArray, QHostAddress(QString::fromUtf8(_ip.c_str())), _port);
}


RC090Packet RC90Client::sendSync(RC090Packet& packet, Unsigned32 msTimeout)
{
    Unsigned32 length = packet.fullPacketLength;
    packet.cookie = _cookie;
    _lastRequestCookieMap[packet.vgsId] = _cookie;  // creates if not in the map, overwrites if in the map
    _cookie++;

    QByteArray byteArray = RC90Serializer::serialize(packet);
    _udpSocket.writeDatagram(byteArray, QHostAddress(QString::fromUtf8(_ip.c_str())), _port);

    RC090Packet reply = _receiveSync(msTimeout);

    // in case we get fragments
    if (reply.fragmentNumber != 0xFF && reply.fragmentCount > 1)
    {
        if (reply.fragmentNumber <= reply.fragmentCount)
            reply = _receiveFragments(reply, msTimeout);
    }

    return reply;

}

RC090Packet RC90Client::_receiveSync(Unsigned32 msTimeout)
{
    QElapsedTimer timer;
    timer.start();
    while( timer.elapsed() < msTimeout )
    {
//        qDebug() << "in _receiveSync";
        if (_udpSocket.hasPendingDatagrams())
        {
//            qDebug() << "hasPendingDatagrams";

            //QByteArray datagram = _udpSocket.receiveDatagram().data();

            QByteArray datagram;
            datagram.resize(_udpSocket.pendingDatagramSize());
            QHostAddress sender;
            quint16 senderPort;

            _udpSocket.readDatagram(datagram.data(), datagram.size(),
                                    &sender, &senderPort);
//            qDebug() << "datagram size:" << datagram.size();
//            qDebug() << "receiveDatagram:" << datagram;
            // convert to RC90
            if(datagram.size() == 0)
                throw RC90Exception("Received no data - connection probably lost");
            try
            {
                RC090Packet reply = RC90Serializer::deserialize(datagram);
                if(_lastRequestCookieMap.contains(reply.vgsId) && _lastRequestCookieMap[reply.vgsId] == reply.cookie)
                {
    //                qDebug() << "done - returning";
                    return reply;
                }
            }
            catch(...)
            {
                throw RC90Exception("Received invalid data - cannot create RC90Packet");
            }


        }
        QThread::msleep(1); // hold this thread, but not other threads
    }
    throw RC90Exception("Timeout");
}

RC090Packet RC90Client::_receiveFragments(RC090Packet reply, Unsigned32 msTimeout)
{
    qDebug() << "Fragments - total count: " << reply.fragmentCount;
    Unsigned8 numberOfFragments = reply.fragmentCount;
    RC090Packet fragments[15];  // max 7 fragments

    if(numberOfFragments > 15)
        throw RC90Exception("Number of fragements is too high");

    fragments[reply.fragmentNumber - 1] = reply;

    Unsigned32 fragmentsToReceive = reply.fragmentCount - 1; // already received 1

    bool errorExit = false;
    do
    {
        RC090Packet fragment = _receiveSync(msTimeout);

        if (fragment.vgsId == reply.vgsId && fragment.fragmentNumber <= reply.fragmentCount)
        {
            fragments[fragment.fragmentNumber - 1] = fragment;
        }
        else
        {
            qDebug() << "Received an unexpected fragment.";
            errorExit = true;
        }


    }
    while (not errorExit && --fragmentsToReceive > 0);

    if (not errorExit)
    {   // All packets received

        qDebug() << "all packets received.";
        int totalDataLength = 0;
        for (int i = 0; i < numberOfFragments; ++i)
            totalDataLength += fragments[i].data.size();

        ByteArray allData;
        allData.reserve(totalDataLength);  // make the vector big enough for all data

        for (int i = 0; i < numberOfFragments; ++i)
        {
            std::copy(fragments[i].data.begin(), fragments[i].data.end(), std::back_inserter(allData));
        }

        reply.data = allData;
        reply.fragmentCount = 1;
        reply.fragmentNumber = 1;
        return reply;
    }
    else
        throw RC90Exception("Receiving multiple rc90 fragments failed.");
}
