#pragma once
#include "RC90BaseClient.h"
#include <QFile>
#include <string>
#include <QMutex>

class RC90Tester;

class RC90FileClient : public RC90BaseClient
{
    friend class RC90Tester;
    Q_OBJECT
public:
    RC90FileClient(const QString& file, bool debugMode = false);
    ~RC90FileClient();

    virtual RC090Packet sendSync(RC090Packet& packet, Unsigned32 msTimeout = 100);
    virtual void sendAsync(RC090Packet& packet);

protected:
    QList<RC090Packet> _readFromFile();
    void _writeToFile(const QList<RC090Packet>& rc90packets);

private:
    RC090Packet _handleRequest(const RC090Packet& packet);
    RC090Packet _handleModify(const RC090Packet& packet);

public slots:
    void saveFile();

private:
    bool _debugMode;
    QFile _file;
    QList<RC090Packet> _packetsInMemory;
    QMutex _lock;
};
