#pragma once
#include <QByteArray>
#include "../datatypes/PicanolTypes.h"

class RC090Packet;

class RC90Serializer
{
public:
    static Unsigned8* serialize(const RC090Packet& packet, Unsigned8* buffer, Unsigned32 maxBufferLength);
    static QByteArray serialize(const RC090Packet& packet);
    static RC090Packet deserialize(const Unsigned8* data, Unsigned32 dataLength);
    static RC090Packet deserialize(QByteArray byteArray);  // TODO: make const ref? Not sure if it will still work though

    static void printTest();
};
