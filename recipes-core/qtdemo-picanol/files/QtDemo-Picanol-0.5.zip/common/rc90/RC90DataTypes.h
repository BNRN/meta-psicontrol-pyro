#pragma once

struct PropertyDataType
{
    enum Enum
    {
        Unknown = 0,

        Bool = 1,
        Unsigned8 = 2,
        Unsigned16 = 3,
        Unsigned32 = 4,
        Unsigned64 = 5,
        Signed8 = 6,
        Signed16 = 7,
        Signed32 = 8,
        Signed64 = 9,
        Float = 10,
        Double = 11,
        String = 12,
        Binary = 13,
        PsiTime = 14,
        Rc060Password = 15,
        TimingPair = 16,
        JsonString = 18,
        Message = 19
    };

};
