#pragma once


struct PropertyUnitType
{
    enum Enum
    {
        None = 0, // No unit
        Number = 1,
        Seconds = 2, // Time
        Degrees = 3, // Angle
        Bar = 4, // Pressure
        Newton = 5, // Force
        RPM = 6, // RotationalSpeed
        Percent = 7, // Fraction
        Meter = 8, // Meter
        MeterPerSecond = 9, // Speed
        Ampere = 10, // Electrical Current
        Celsius = 11, // Temperature
        MeterPerSecondSquared = 12, // Acceleration
        NormalCubicMeterPerHour = 13, // FlowRate
        BarPerSecond = 14, // Bar/second, Pressure change over time
        DegreesPerSecondSquared = 15,
        DTEX = 16,
        MeterPerPick = 17, // lineair speed
        SecondsSquare = 18,
        PerMeter = 19, // inverse of Meter
        Unsigned64Thousands = 20
    };
};

