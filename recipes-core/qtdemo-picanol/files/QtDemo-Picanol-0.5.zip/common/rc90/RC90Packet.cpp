#include "RC90Packet.h"

#include <string>
#include "../datatypes/BBId.h"
#include "../datatypes/ByteConverter.h"
#include "RC90Value.h"

RC090Packet::RC090Packet() :
        arcNetSource(1),
        arcNetDestination(2),
        picanolPortControl(0),
        picanolSource(32),
        picanolDestination(0),
        protocolId(90),
        messageLength(27),
        requestType(),
        vgsId(0),
        dataInfo(),
        dataType(),
        dataFormat(),
        dataUnit(),
        modifyCode(),
        fragmentCount(),
        fragmentNumber(),
        cookie(0xFF),
        data(),
        fullPacketLength(27)  // 7 bytes arc net/picanol msg header + 20 bytes rc header
{
    arcNetOffset[0] = 0;
    arcNetOffset[1] = 0;
}

RC090Packet::~RC090Packet()
{

}

void RC090Packet::print()
{
    // TODO
}

RC090Packet RC090Packet::createRequest(Unsigned32 vgsId)
{
    RC090Packet ret;

    ret.vgsId = vgsId;
    ret.requestType = RequestType::Request;
    ret.messageLength = RC090Header::REQUEST_HEADER_LENGTH;

    return ret;
}

RC090Packet RC090Packet::createModify(RC090Packet& request, const RC90Value& value)
{
    switch(request.dataFormat)
    {
    case PropertyDataType::Unknown:
    case PropertyDataType::Rc060Password:
    case PropertyDataType::Message:
        break;
    case PropertyDataType::PsiTime:
        return createModify(request, (PicanolTime)value);
    case PropertyDataType::Bool:
        return createModify(request, (bool)value);
    case PropertyDataType::Unsigned8:
        return createModify(request, (Unsigned8)value);
    case PropertyDataType::Unsigned16:
        return createModify(request, (Unsigned16)value);
    case PropertyDataType::Unsigned32:
        return createModify(request, (Unsigned32)value);
    case PropertyDataType::Unsigned64:
        return createModify(request, (Unsigned64)value);
    case PropertyDataType::Signed8:
        return createModify(request, (Signed8)value);
    case PropertyDataType::Signed16:
        return createModify(request, (Signed16)value);
    case PropertyDataType::Signed32:
        return createModify(request, (Signed32)value);
    case PropertyDataType::Signed64:
        return createModify(request, (Signed64)value);
    case PropertyDataType::Float:
        return createModify(request, (float)value);
    case PropertyDataType::Double:
        return createModify(request, (double)value);
    case PropertyDataType::String:
    case PropertyDataType::JsonString:
        return createModify(request, (std::string)value);
    case PropertyDataType::Binary:
        return createModify(request, value.getByteArray(), value.getLength(), false);
    case PropertyDataType::TimingPair:
        return createModify(request, (TimingPair)value);
    }
    throw InvalidDataFormatException("DataFormat not supported.");
}

RC090Packet RC090Packet::createModify(RC090Packet& request, bool value)
{
    ByteArray byteArray;
    byteArray.push_back(value ? 1 : 0);
    return createModify(request, byteArray, 1, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, Signed8 value)
{
    ByteArray byteArray;
    byteArray.push_back(value);
    return createModify(request, byteArray, 1, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, Unsigned8 value)
{
    ByteArray byteArray;
    byteArray.push_back(value);
    return createModify(request, byteArray, 1, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, Signed16 value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 2, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, Unsigned16 value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 2, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, Signed32 value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 4, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, Unsigned32 value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 4, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, Signed64 value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 8, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, Unsigned64 value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 8, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, float value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 4, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, double value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 8, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, const std::string& value)
{
    Unsigned32 length = value.length();
    ByteArray byteArray;
    bool nullTerminated = false;
    for(Unsigned32 i = 0; i<length; ++i)
    {
        byteArray.push_back(value.at(i));
        if(i == length - 1)
            nullTerminated = (value.at(i) == 0);
    }
    if (not nullTerminated)
        byteArray.push_back(0);

    return createModify(request, byteArray, length, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, TimingPair value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 8, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, PicanolTime value)
{
    return createModify(request, ByteConverter::toDataBytes(value), 8, false);
}

RC090Packet RC090Packet::createModify(RC090Packet& request, ByteArray data, Unsigned32 dataLength, bool reverseUnsigned8s)
{
    RC090Packet ret;

//    if (reverseUnsigned8s)
//        Util.InplaceReverseUnsigned8s(data);

    ret.vgsId = request.vgsId;
    ret.requestType = RequestType::Modify;
    ret.messageLength = (Unsigned16)(RC090Header::MODIFY_HEADER_LENGTH + dataLength);

    ret.dataType = request.dataType;
    ret.dataFormat = request.dataFormat;
    ret.data = data;

    ret.fullPacketLength = RC090Header::OFFSET_DATA + dataLength;

    return ret;
}
