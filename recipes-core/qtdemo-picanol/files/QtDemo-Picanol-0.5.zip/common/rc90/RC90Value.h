/*
 * RC90Value.h
 *
 *  Created on: 25 sep. 2017
 *      Author: slr
 */

#pragma once
#include "../exceptions/converstionexceptions.h"
#include <string>
#include <QString>

#include "PicanolTypes.h"
#include "../datatypes/PicanolTime.h"
#include "RC90DataTypes.h"
#include "RC90Protocol.h"

class RC090Packet;

class RC90Value
{
public:
    RC90Value();
    RC90Value(const RC090Packet& packet);

    RC90Value(float value);
    RC90Value(double value);
    RC90Value(bool value);
    RC90Value(Unsigned8 value);
    RC90Value(Signed8 value);
    RC90Value(Unsigned16 value);
    RC90Value(Signed16 value);
    RC90Value(Unsigned32 value);
    RC90Value(Signed32 value);
    RC90Value(Unsigned64 value);
    RC90Value(Signed64 value);
    RC90Value(const std::string& value);
    RC90Value(const QString& value);
    RC90Value(TimingPair value);
    RC90Value(const ByteArray& value);
    RC90Value(PicanolTime);
    RC90Value(const ByteArray& value, PropertyDataType::Enum dataFormat);

    operator bool() const;
    operator Signed8() const;
    operator Signed16() const;
    operator Signed32() const;
    operator Signed64() const;
    operator Unsigned8() const;
    operator Unsigned16() const;
    operator Unsigned32() const;
    operator Unsigned64() const;
    operator float() const;
    operator double() const;
    operator std::string() const;
    operator TimingPair() const;
    operator PicanolTime() const;

    ByteArray getByteArray() const;
    Unsigned32 getLength() const;
    PropertyDataType::Enum getPropertyDataType() const;
    DataType::Enum getDataType() const;

    std::string getValueAsString();  // in case we don't care about the type.
    QString getValueAsQString();

    void setDataFormat(PropertyDataType::Enum dataFormat);

private:
    void _convertBinaryDataToDataFormat();

public:
    union
    {
        bool boolValue;  // 1 byte

        Signed8 signed8Value;   // 1 byte
        Signed16 signed16Value; // 2 byte
        Signed32 signed32Value; // 4 byte
        Signed64 signed64Value; // 8 byte

        Unsigned8 unsigned8Value;   // 1 byte
        Unsigned16 unsigned16Value; // 2 byte
        Unsigned32 unsigned32Value; // 4 byte
        Unsigned64 unsigned64Value; // 8 byte

        float floatValue;   // 4 bytes
        double doubleValue; // 8 bytes

        Unsigned8 bytes[12]; // 12 bytes (max)

        struct
        {
            float onValue;
            float offValue;
        };  // 8 bytes

        struct
        {
            Unsigned32 size;  // 4 bytes
            Unsigned8* data;  // 4 or 8 bytes
        }; // 8 bytes or 12 bytes (32 bit or 64 bit system)
    } storedData; // Max 12 bytes

private:
    PicanolTime _psiTime;
    std::string _stringData;
    ByteArray _binaryData;
    Unsigned32 _dataLength;
    PropertyDataType::Enum _dataFormat;
    DataType::Enum _dataType;



};


