#include "RC90Serializer.h"
#include <iostream>

#include "rcexception.h"
#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#include "../datatypes/ByteConverter.h"
#include "RC90DataTypes.h"
#include "RC90Packet.h"
#include "RC90Protocol.h"

QByteArray RC90Serializer::serialize(const RC090Packet& packet)
{
    QByteArray byteArray;
    byteArray.reserve(packet.data.size() + RC090Header::OFFSET_DATA);


    byteArray.append(packet.arcNetSource);       // 0
    byteArray.append(packet.arcNetDestination);  // 1
    byteArray.append((packet.arcNetOffset)[0]);  // 1
    byteArray.append((packet.arcNetOffset)[1]);  // 1
    byteArray.append(packet.picanolPortControl); // 4
    byteArray.append(packet.picanolSource);      // 5
    byteArray.append(packet.picanolDestination); // 6

    byteArray.append(packet.protocolId);         // 7
    ByteArray msgLength = ByteConverter::toDataBytes(packet.messageLength);
    byteArray.append(msgLength[0]);
    byteArray.append(msgLength[1]);
    byteArray.append((Unsigned8)packet.requestType);
    ByteArray id = ByteConverter::toDataBytes(packet.vgsId);
    for(int i = 0; i<4; ++i)
        byteArray.append(id[i]);

    ByteArray dataInfo = ByteConverter::toDataBytes(packet.dataInfo.getValue());
    for(int i = 0; i<4; ++i)
        byteArray.append(dataInfo[i]);

    byteArray.append((Unsigned8)packet.dataType);
    byteArray.append((Unsigned8)packet.dataFormat);
    ByteArray dataUnit = ByteConverter::toDataBytes(packet.dataUnit);
    byteArray.append(dataUnit[0]);
    byteArray.append(dataUnit[1]);

    byteArray.append((Unsigned8)packet.modifyCode);
    byteArray.append(0xFF);  // Fragment
    byteArray.append(packet.cookie);
    byteArray.append(0xFF);  // padding

    if (packet.data.size() > 0)
    {
        ByteArray::const_iterator current = packet.data.begin();
        ByteArray::const_iterator end = packet.data.end();
        for (int i = 0; current != end; ++current, ++i)
        {
            byteArray.append(*current);
        }
    }

    return byteArray;
}


Unsigned8* RC90Serializer::serialize(const RC090Packet& packet, Unsigned8* buffer, Unsigned32 maxBufferLength)
{

    if (packet.data.size() + RC090Header::OFFSET_DATA > maxBufferLength)
        throw RC90Exception("Buffer size to small for packet.");

    *buffer = packet.arcNetSource;       // 0
    *(buffer + 1) = packet.arcNetDestination;  // 1
    *(buffer + 2) = (packet.arcNetOffset)[0];  // 1
    *(buffer + 3) = (packet.arcNetOffset)[1];  // 1
    *(buffer + 4) = packet.picanolPortControl; // 4
    *(buffer + 5) = packet.picanolSource;      // 5
    *(buffer + 6) = packet.picanolDestination; // 6

    *(buffer + 7) = packet.protocolId;         // 7
    ByteArray msgLength = ByteConverter::toDataBytes(packet.messageLength);
    *(buffer + 8) = msgLength[0];
    *(buffer + 9) = msgLength[1];
    *(buffer + 10) = (Unsigned8)packet.requestType;
    ByteArray id = ByteConverter::toDataBytes(packet.vgsId);
    for(int i = 0; i<4; ++i)
        *(buffer + 11 + i) = id[i];

    ByteArray dataInfo = ByteConverter::toDataBytes(packet.dataInfo.getValue());
    for(int i = 0; i<4; ++i)
        *(buffer + 15 + i) = dataInfo[i];

    *(buffer + 19) = (Unsigned8)packet.dataType;
    *(buffer + 20) = (Unsigned8)packet.dataFormat;
    ByteArray dataUnit = ByteConverter::toDataBytes(packet.dataUnit);
    *(buffer + 21) = dataUnit[0];
    *(buffer + 22) = dataUnit[1];

    *(buffer + 23) = (Unsigned8)packet.modifyCode;
    *(buffer + 24) = 0xFF;  // Fragment
    *(buffer + 25) = packet.cookie;
    *(buffer + 26) = 0xFF;  // padding

    if (packet.data.size() > 0)
    {
        ByteArray::const_iterator current = packet.data.begin();
        ByteArray::const_iterator end = packet.data.end();
        for (int i = 0; current != end; ++current, ++i)
        {
            *(buffer + 27 + i) = *current;
        }
    }

    return buffer;
}

RC090Packet RC90Serializer::deserialize(QByteArray byteArray)
{
    RC090Packet packet;

    packet.arcNetSource = byteArray[0];
    packet.arcNetDestination = byteArray[1];
    packet.arcNetOffset[0] = byteArray[2];
    packet.arcNetOffset[1] = byteArray[3];

    packet.picanolPortControl = byteArray[4];
    packet.picanolSource = byteArray[5];
    packet.picanolDestination = byteArray[6];

    packet.protocolId = byteArray[RC090Header::OFFSET_PROTOCOLID];
    packet.messageLength = ByteConverter::getU16FromData(byteArray, RC090Header::OFFSET_MESSAGELENGTH);

    packet.requestType = (RequestType::Enum)(ByteConverter::getU8FromData(byteArray, RC090Header::OFFSET_REQUESTTYPE));
    packet.vgsId = ByteConverter::getU32FromData(byteArray, RC090Header::OFFSET_BBID);

    packet.fullPacketLength = byteArray.size();

    if (packet.requestType != RequestType::Request)
    {
        if (packet.messageLength < RC090Header::OFFSET_DATA - RC090Header::OFFSET_REQUESTTYPE)
        {
            //std::string exception = "Packet message length is invalid (should be greater than " + std::to_string(RC090Header::OFFSET_DATA - RC090Header::OFFSET_REQUESTTYPE) + ", but is " + std::to_string(packet.messageLength) + " )";
            //throw RC90Exception(exception.c_str());
            throw RC90Exception("Packet message length is invalid.");
        }
//            throw new InvalidDataException(string.Format("Protocol error rcLength < {0} ({1})", RC090Header::OFFSET_DATA, packet.messageLength));

        packet.dataInfo.field.value = ByteConverter::getU32FromData(byteArray, RC090Header::OFFSET_DATAINFO);
        packet.dataType = (DataType::Enum)(ByteConverter::getU8FromData(byteArray, RC090Header::OFFSET_DATATYPE));
        packet.dataFormat = (PropertyDataType::Enum)(ByteConverter::getU8FromData(byteArray, RC090Header::OFFSET_DATAFORMAT));
        packet.dataUnit = (PropertyUnitType::Enum)ByteConverter::getU16FromData(byteArray, RC090Header::OFFSET_DATAUNIT);

        packet.modifyCode = (ModifyCode::Enum)(ByteConverter::getU8FromData(byteArray, RC090Header::OFFSET_MODIFYCODE));

        packet.fragmentCount = (Unsigned8)((byteArray[RC090Header::OFFSET_FRAGMENTS] & ((Unsigned8)0xF0)) >> 4);
        packet.fragmentNumber = (Unsigned8)(byteArray[RC090Header::OFFSET_FRAGMENTS] & ((Unsigned8)0x0F));

        packet.cookie = byteArray[RC090Header::OFFSET_COOKIE];

        if (byteArray.size() > RC090Header::OFFSET_DATA)
        {

            packet.data.clear();  // remove any data
            Unsigned32 dataLength = byteArray.size() - RC090Header::OFFSET_DATA;
            packet.data.resize(dataLength);
            for(Unsigned32 i = 0; i < dataLength; ++i)
                packet.data[i] = byteArray[RC090Header::OFFSET_DATA + i];  // there is probably a more efficient way to do this

        }
    }

    return packet;
}

RC090Packet RC90Serializer::deserialize(const Unsigned8* data, Unsigned32 dataLength)
{
//    if (data == NULL)
//        throw new InvalidDataException("Data is null");
//
//    if (data.Length < RC090Header.OFFSET_DATAINFO)
//        throw new InvalidDataException(string.Format("Data length < {0}", RC090Header.OFFSET_DATA));
//
//    if (data[RC090Header.OFFSET_PROTOCOLID] != 90)
//        throw new InvalidDataException(string.Format("Protocol error RCId != 90 ({0})", data[RC090Header.OFFSET_PROTOCOLID]));

    ByteArray byteArray;
    byteArray.resize(dataLength);
    std::copy(data, data+dataLength, byteArray.begin());


    RC090Packet packet;

    packet.arcNetSource = byteArray[0];
    packet.arcNetDestination = byteArray[1];
    packet.arcNetOffset[0] = byteArray[2];
    packet.arcNetOffset[1] = byteArray[3];

    packet.picanolPortControl = byteArray[4];
    packet.picanolSource = byteArray[5];
    packet.picanolDestination = byteArray[6];

    packet.protocolId = byteArray[RC090Header::OFFSET_PROTOCOLID];
    packet.messageLength = ByteConverter::getU16FromData(byteArray, RC090Header::OFFSET_MESSAGELENGTH);

    packet.requestType = (RequestType::Enum)(byteArray[RC090Header::OFFSET_REQUESTTYPE]);
    packet.vgsId = ByteConverter::getU32FromData(byteArray, RC090Header::OFFSET_BBID);

    packet.fullPacketLength = dataLength;

    if (packet.requestType != RequestType::Request)
    {
        if (packet.messageLength < RC090Header::OFFSET_DATA - RC090Header::OFFSET_REQUESTTYPE)
        {
            //std::string exception = "Packet message length is invalid (should be greater than " + std::to_string(RC090Header::OFFSET_DATA - RC090Header::OFFSET_REQUESTTYPE) + ", but is " + std::to_string(packet.messageLength) + " )";
            //throw RC90Exception(exception.c_str());
            throw RC90Exception("Packet message length is invalid.");
        }
//            throw new InvalidDataException(string.Format("Protocol error rcLength < {0} ({1})", RC090Header::OFFSET_DATA, packet.messageLength));

        packet.dataInfo.field.value = ByteConverter::getU32FromData(byteArray, RC090Header::OFFSET_DATAINFO);
        packet.dataType = (DataType::Enum)byteArray[RC090Header::OFFSET_DATATYPE];
        packet.dataFormat = (PropertyDataType::Enum)byteArray[RC090Header::OFFSET_DATAFORMAT];
        packet.dataUnit = (PropertyUnitType::Enum)ByteConverter::getU16FromData(byteArray, RC090Header::OFFSET_DATAUNIT);

        packet.modifyCode = (ModifyCode::Enum)byteArray[RC090Header::OFFSET_MODIFYCODE];

        packet.fragmentCount = (Unsigned8)((byteArray[RC090Header::OFFSET_FRAGMENTS] & ((Unsigned8)0xF0)) >> 4);
        packet.fragmentNumber = (Unsigned8)(byteArray[RC090Header::OFFSET_FRAGMENTS] & ((Unsigned8)0x0F));

        packet.cookie = byteArray[RC090Header::OFFSET_COOKIE];

        if (dataLength > RC090Header::OFFSET_DATA)
        {

            packet.data.clear();  // remove any data
            packet.data.resize(dataLength - RC090Header::OFFSET_DATA);
            std::copy((data + RC090Header::OFFSET_DATA), (data + dataLength), packet.data.begin());

        }
    }

    return packet;
}

void RC90Serializer::printTest()
{
    std::cout << "Test" << std::endl;
}
