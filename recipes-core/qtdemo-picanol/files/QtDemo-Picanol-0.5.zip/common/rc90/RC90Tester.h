#pragma once
#include "RC90Client.h"
#include "RC90FileClient.h"

class RC90Tester
{
public:
    RC90Tester();

    void test();
    void testInvalidId();
    void tryAllIds();
    void tryFragments();

private:
    bool _tryRequest(RC090Packet& request, RC090Packet& answer);

private:
    RC90Client _rc90udpClient;
    RC90FileClient _rc90fileClient;
};
