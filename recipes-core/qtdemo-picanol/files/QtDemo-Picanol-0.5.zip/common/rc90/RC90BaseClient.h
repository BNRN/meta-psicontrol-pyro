#pragma once
#include <QObject>
#include "RC90Packet.h"

class RC90BaseClient : public QObject
{
    Q_OBJECT
public:
    RC90BaseClient(QObject* parent = NULL) : QObject(parent) {}
    virtual ~RC90BaseClient() {}

    virtual RC090Packet sendSync(RC090Packet& packet, Unsigned32 msTimeout = 100) = 0;
    virtual void sendAsync(RC090Packet& packet) = 0;

signals:
    void receivedRCPacket(RC090Packet rcPacket);  // the derived classes can emit this signal
};
