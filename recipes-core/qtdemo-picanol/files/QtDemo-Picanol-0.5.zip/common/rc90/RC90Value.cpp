/*
 * RC90Value.cpp
 *
 *  Created on: 25 sep. 2017
 *      Author: slr
 */
#include "RC90Value.h"

#include <cstdio>
#include <iostream>
#include <sstream>
#include "../datatypes/ByteConverter.h"
#include "RC90Packet.h"
#include <QDebug>

RC90Value::RC90Value()
{
    _dataLength = 0;
    _dataFormat = PropertyDataType::Unknown;
    _dataType = DataType::Unknown;
}

RC90Value::RC90Value(const RC090Packet& packet)
{
    _binaryData = packet.data;
    _dataLength = _binaryData.size();
    _dataFormat = packet.dataFormat;
    _dataType = packet.dataType;
    _convertBinaryDataToDataFormat();
}

void RC90Value::_convertBinaryDataToDataFormat()
{
    try
    {
        switch(_dataFormat)
        {
        case PropertyDataType::Unknown:
        case PropertyDataType::Binary:
        case PropertyDataType::Rc060Password:
        case PropertyDataType::Message:
            break;
        case PropertyDataType::PsiTime:
        {
            ByteArray psiTimeArray;
            for(Unsigned32 i = 0; i < 8; ++i)
                psiTimeArray.push_back(_binaryData[i]);
            _psiTime = PicanolTime(psiTimeArray);
            break;
        }
        case PropertyDataType::Bool:
            storedData.boolValue = ByteConverter::getBoolFromData(_binaryData, 0);
            break;
        case PropertyDataType::Float:
            storedData.floatValue = ByteConverter::getFloatFromData(_binaryData, 0);
            break;
        case PropertyDataType::Double:
            storedData.doubleValue = ByteConverter::getDoubleFromData(_binaryData, 0);
            break;
        case PropertyDataType::TimingPair:
        {
            TimingPair tp = ByteConverter::getTimingPairFromData(_binaryData, 0);
            storedData.onValue = tp.first;
            storedData.offValue = tp.second;
            break;
        }
        case PropertyDataType::Unsigned8:
            storedData.unsigned8Value = ByteConverter::getU8FromData(_binaryData, 0);
            break;
        case PropertyDataType::Unsigned16:
            storedData.unsigned16Value = ByteConverter::getU16FromData(_binaryData, 0);
            break;
        case PropertyDataType::Unsigned32:
            storedData.unsigned32Value = ByteConverter::getU32FromData(_binaryData, 0);
            break;
        case PropertyDataType::Unsigned64:
            storedData.unsigned64Value = ByteConverter::getU64FromData(_binaryData, 0);
            break;
        case PropertyDataType::Signed8:
            storedData.signed8Value = ByteConverter::getS8FromData(_binaryData, 0);
            break;
        case PropertyDataType::Signed16:
            storedData.signed16Value = ByteConverter::getS16FromData(_binaryData, 0);
            break;
        case PropertyDataType::Signed32:
            storedData.signed32Value = ByteConverter::getS32FromData(_binaryData, 0);
            break;
        case PropertyDataType::Signed64:
            storedData.signed64Value = ByteConverter::getS64FromData(_binaryData, 0);
            break;
        case PropertyDataType::String:
        case PropertyDataType::JsonString:
            _stringData = ByteConverter::getStringFromData(_binaryData, 2);
            break;
        }
    }
    catch (const InvalidDataLengthException& e)
    {
        qDebug() << e.what();
    }
}

RC90Value::RC90Value(const ByteArray& value)
{
    _binaryData = value;
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Binary;
    _dataType = DataType::Unknown;
}

RC90Value::RC90Value(PicanolTime value)
{
    _psiTime = value;
    _binaryData = ByteConverter::toDataBytes(value);;
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::PsiTime;
    _dataType = DataType::Unknown;
}

RC90Value::RC90Value(const ByteArray& value, PropertyDataType::Enum dataFormat)
{
    _binaryData = value;
    _dataLength = _binaryData.size();
    _dataFormat = dataFormat;
    _dataType = DataType::Unknown;
    _convertBinaryDataToDataFormat();
}

RC90Value::RC90Value(float value)
{
    storedData.floatValue = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Float;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(double value)
{
    storedData.doubleValue = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Double;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(bool value)
{
    storedData.boolValue = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Bool;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(Unsigned8 value)
{
    storedData.unsigned8Value = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Unsigned8;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(Signed8 value){
    storedData.signed8Value = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Signed8;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(Unsigned16 value)
{
    storedData.unsigned16Value = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Unsigned16;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(Signed16 value)
{
    storedData.signed16Value = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Signed16;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(Unsigned32 value)
{
    storedData.unsigned32Value = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Unsigned32;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(Signed32 value)
{
    storedData.signed32Value = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Signed32;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(Unsigned64 value)
{
    storedData.unsigned64Value = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Unsigned64;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(Signed64 value)
{
    storedData.signed64Value = value;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::Signed64;
    _dataType = DataType::Unknown;
}
RC90Value::RC90Value(const std::string& value)
{
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::String;
    _dataType = DataType::Unknown;
}

RC90Value::RC90Value(const QString& value)
{
    _binaryData = ByteConverter::toDataBytes(value.toUtf8().toStdString());
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::String;
    _dataType = DataType::Unknown;
}

RC90Value::RC90Value(TimingPair value)
{
    storedData.onValue = value.first;
    storedData.offValue = value.second;
    _binaryData = ByteConverter::toDataBytes(value);
    _dataLength = _binaryData.size();
    _dataFormat = PropertyDataType::TimingPair;
    _dataType = DataType::Unknown;
}

void RC90Value::setDataFormat(PropertyDataType::Enum dataFormat)
{
    _dataFormat = dataFormat;
}

RC90Value::operator bool() const
{
    return storedData.boolValue;
}
RC90Value::operator Signed8() const
{
    return storedData.signed8Value;
}
RC90Value::operator Signed16() const
{
    return storedData.signed16Value;
}
RC90Value::operator Signed32() const
{
    return storedData.signed32Value;
}
RC90Value::operator Signed64() const
{
    return storedData.signed64Value;
}
RC90Value::operator Unsigned8() const
{
    return storedData.unsigned8Value;
}
RC90Value::operator Unsigned16() const
{
    return storedData.unsigned16Value;
}
RC90Value::operator Unsigned32() const
{
    return storedData.unsigned32Value;
}
RC90Value::operator Unsigned64() const
{
    return storedData.unsigned64Value;
}
RC90Value::operator float() const
{
    return storedData.floatValue;
}
RC90Value::operator double() const
{
    return storedData.doubleValue;
}
RC90Value::operator std::string() const
{
    return _stringData;
}
RC90Value::operator TimingPair() const
{
    return TimingPair(storedData.onValue, storedData.offValue);
}
RC90Value::operator PicanolTime() const
{
    return _psiTime;
}


ByteArray RC90Value::getByteArray() const
{
    return _binaryData;
}
Unsigned32 RC90Value::getLength() const
{
    return _dataLength;
}
PropertyDataType::Enum RC90Value::getPropertyDataType() const
{
    return _dataFormat;
}
DataType::Enum RC90Value::getDataType() const
{
    return _dataType;
}

QString RC90Value::getValueAsQString()
{
    return QString::fromStdString(getValueAsString());
}


std::string RC90Value::getValueAsString()
{
    switch(_dataFormat)
    {
    default:
        throw InvalidDataTypeException("Dataformat not handled in RC90Value.getValueAsString()");
        break;
    case PropertyDataType::PsiTime:
        return _psiTime.asString().toStdString();
    case PropertyDataType::Bool:
        return std::to_string(ByteConverter::getBoolFromData(_binaryData, 0));
    case PropertyDataType::Float:
        return std::to_string(ByteConverter::getFloatFromData(_binaryData, 0));
    case PropertyDataType::Double:
        return std::to_string(ByteConverter::getDoubleFromData(_binaryData, 0));
    case PropertyDataType::Unsigned8:
        return std::to_string(ByteConverter::getU8FromData(_binaryData, 0));
    case PropertyDataType::Unsigned16:
        return std::to_string(ByteConverter::getU16FromData(_binaryData, 0));
    case PropertyDataType::Unsigned32:
        return std::to_string(ByteConverter::getU32FromData(_binaryData, 0));
    case PropertyDataType::Unsigned64:
        return std::to_string(ByteConverter::getU64FromData(_binaryData, 0));
    case PropertyDataType::Signed8:
        return std::to_string(ByteConverter::getS8FromData(_binaryData, 0));
    case PropertyDataType::Signed16:
        return std::to_string(ByteConverter::getS16FromData(_binaryData, 0));
    case PropertyDataType::Signed32:
        return std::to_string(ByteConverter::getS32FromData(_binaryData, 0));
    case PropertyDataType::Signed64:
        return std::to_string(ByteConverter::getS64FromData(_binaryData, 0));
    case PropertyDataType::String:
    case PropertyDataType::JsonString:
        return ByteConverter::getStringFromData(_binaryData, 2);
    case PropertyDataType::TimingPair:
    {
        std::stringstream ss;
        ss << std::to_string(ByteConverter::getFloatFromData(_binaryData, 0));
        ss << " => ";
        ss << std::to_string(ByteConverter::getFloatFromData(_binaryData, 4));
        return  ss.str();
    }
    case PropertyDataType::Binary:
    {
        std::stringstream ss;
        for(Unsigned32 i = 0; i<_binaryData.size(); ++i)
            ss << std::to_string(_binaryData[i]) << " ";
        return ss.str();
    }
    }
}



