#pragma once

#include "../datatypes/PicanolTypes.h"


struct RequestType
{
    enum Enum
    {
        Request = 0,
        RequestReply = 1, // Context will clarify ...
        Modify = 1,
        ModifyReply = 2
    };
};

struct DataType
{
    enum Enum
    {
        Unknown = -1,
        Value = 1,
        Range = 2,
        Enumeration = 3,
        Array = 4
    };
};

struct ModifyCode
{
    enum Enum
    {
        Success = 0,
        ReadOnly = 1,
        WriteOnly = 2,
        OutOfRange = 3,
        WrongValue = 4,
        NotFound = 5,
        UnexpectedError = 6,
        NotImplemented = 7,
        TypeMismatch = 8,
        InputError = 9,
        PropertyError = 10,
        WrongRequestType = 11,  // RequestType is not 'Request' nor 'Modify'
        Message = 255
    };
};

    // 32 bit-field
struct DataInfoField
{
public:
    union {
        Unsigned32 value;
        struct {
            Unsigned32 tail: 29;
            Unsigned32 writable : 1;
            Unsigned32 readable : 1;
            Unsigned32 bit0 : 1;
        };
    } field;


    bool getBit(int index)
    {
        return (field.value & (1 << index)) != 0;
    }

    void setBit(int index, bool value)
    {
        if (value)
            field.value |= (Unsigned32)(1 << index);
        else
            field.value &= (Unsigned32)(~(1 << index));
    }

    Unsigned32 getValue() const { return field.value; }


};

class RC090Header
{
public:
    static const Unsigned32 SIZE_PROTOCOLID    = 1;
    static const Unsigned32 SIZE_MESSAGELENGTH = 2;
    static const Unsigned32 SIZE_REQUESTTYPE   = 1;
    static const Unsigned32 SIZE_BBID          = 4;
    static const Unsigned32 SIZE_DATAINFO      = 4;
    static const Unsigned32 SIZE_DATATYPE      = 1;
    static const Unsigned32 SIZE_DATAFORMAT    = 1;
    static const Unsigned32 SIZE_DATAUNIT      = 2;
    static const Unsigned32 SIZE_MODIFYCODE    = 1;
    static const Unsigned32 SIZE_FRAGMENTS     = 1;
    static const Unsigned32 SIZE_COOKIE        = 1;
    static const Unsigned32 SIZE_PADDING       = 1;

    static const Unsigned32 OFFSET_PROTOCOLID    = 7;
    static const Unsigned32 OFFSET_MESSAGELENGTH = OFFSET_PROTOCOLID    + SIZE_PROTOCOLID;
    static const Unsigned32 OFFSET_REQUESTTYPE   = OFFSET_MESSAGELENGTH + SIZE_MESSAGELENGTH;
    static const Unsigned32 OFFSET_BBID          = OFFSET_REQUESTTYPE   + SIZE_REQUESTTYPE;
    static const Unsigned32 OFFSET_DATAINFO      = OFFSET_BBID          + SIZE_BBID;
    static const Unsigned32 OFFSET_DATATYPE      = OFFSET_DATAINFO      + SIZE_DATAINFO;
    static const Unsigned32 OFFSET_DATAFORMAT    = OFFSET_DATATYPE      + SIZE_DATATYPE;
    static const Unsigned32 OFFSET_DATAUNIT      = OFFSET_DATAFORMAT    + SIZE_DATAFORMAT;
    static const Unsigned32 OFFSET_MODIFYCODE    = OFFSET_DATAUNIT      + SIZE_DATAUNIT;
    static const Unsigned32 OFFSET_FRAGMENTS     = OFFSET_MODIFYCODE    + SIZE_MODIFYCODE;
    static const Unsigned32 OFFSET_COOKIE        = OFFSET_FRAGMENTS     + SIZE_FRAGMENTS;
    static const Unsigned32 OFFSET_PADDING       = OFFSET_COOKIE        + SIZE_COOKIE;
    static const Unsigned32 OFFSET_DATA          = OFFSET_PADDING       + SIZE_PADDING;

    // This the size of the header for a modify request.
    // A modify request must be at least this length.
    // A modify reply must be exactly this length.
    static const Unsigned32 MODIFY_HEADER_LENGTH = SIZE_REQUESTTYPE
                                             + SIZE_BBID
                                             + SIZE_DATAINFO
                                             + SIZE_DATATYPE
                                             + SIZE_DATAFORMAT
                                             + SIZE_DATAUNIT
                                             + SIZE_MODIFYCODE
                                             + SIZE_FRAGMENTS
                                             + SIZE_COOKIE
                                             + SIZE_PADDING;

    // Only 4 fields are required for a request
    // of which 2 fields are counted for the length
    static const Unsigned32 REQUEST_HEADER_LENGTH = SIZE_REQUESTTYPE
                                              + SIZE_BBID;

    static const Unsigned32 MAXIMUM_FRAGMENT_LENGTH = 520;
    static const Unsigned32 MAXIMUM_MESSAGE_LENGTH_VALUE = MAXIMUM_FRAGMENT_LENGTH + MODIFY_HEADER_LENGTH;
};
