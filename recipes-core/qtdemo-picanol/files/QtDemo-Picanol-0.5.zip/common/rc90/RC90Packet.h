#pragma once
#include <string>

#include "../datatypes/PicanolTypes.h"
#include "../datatypes/PicanolTime.h"
#include "RC90DataTypes.h"
#include "RC90Protocol.h"
#include "RC90UnitTypes.h"

class RC90Value;

class RC090Packet
{
public:

    RC090Packet();
    ~RC090Packet();

    void print();
    static RC090Packet createRequest(Unsigned32 BBId);
    static RC090Packet createModify(RC090Packet& request, bool value);
    static RC090Packet createModify(RC090Packet& request, Signed8 value);
    static RC090Packet createModify(RC090Packet& request, Unsigned8 value);
    static RC090Packet createModify(RC090Packet& request, Signed16 value);
    static RC090Packet createModify(RC090Packet& request, Unsigned16 value);
    static RC090Packet createModify(RC090Packet& request, Signed32 value);
    static RC090Packet createModify(RC090Packet& request, Unsigned32 value);
    static RC090Packet createModify(RC090Packet& request, Signed64 value);
    static RC090Packet createModify(RC090Packet& request, Unsigned64 value);
    static RC090Packet createModify(RC090Packet& request, float value);
    static RC090Packet createModify(RC090Packet& request, double value);
    static RC090Packet createModify(RC090Packet& request, const std::string& value);
    static RC090Packet createModify(RC090Packet& request, ByteArray data, Unsigned32 dataLength, bool reverseUnsigned8s);
    static RC090Packet createModify(RC090Packet& request, const RC90Value& value);
    static RC090Packet createModify(RC090Packet& request, TimingPair value);
    static RC090Packet createModify(RC090Packet& request, PicanolTime value);


    Unsigned8 arcNetSource;
    Unsigned8 arcNetDestination;
    Unsigned8 arcNetOffset[2];
    Unsigned8 picanolPortControl;
    Unsigned8 picanolSource;
    Unsigned8 picanolDestination;
    Unsigned8 protocolId;
    Unsigned16 messageLength;
    RequestType::Enum requestType;
    Unsigned32 vgsId;
    DataInfoField dataInfo;
    DataType::Enum dataType;
    PropertyDataType::Enum dataFormat;
    PropertyUnitType::Enum dataUnit;
    ModifyCode::Enum modifyCode;
    Unsigned8 fragmentCount;
    Unsigned8 fragmentNumber;
    Unsigned8 cookie;
    ByteArray data;
    Unsigned32 fullPacketLength;
};
