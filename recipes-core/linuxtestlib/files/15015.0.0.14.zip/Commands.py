"""
Commands.py
Compatible python 2.7 - 3+

Copyright (c), PsiControl Mechatronics NV, All rights reserved.
"""

import types
import time
import logging
import os
import sys
import random

path = os.path.abspath(os.path.join(__file__, '..', '..', '../15016/main'))  # 2015
if path not in sys.path:
    sys.path.append(path)

from version import *
from lib.TypeChecking import *
from lib.utils import cmd

list_of_commands = {}


class Command:
    """
    generic class for a command. It contains a generic setup & teardown, a name and a function to execute.
    The function to execute should accept a logger as argument and return a boolean indicating its success
    """

    @accepts(str, str, types.FunctionType, int)
    def __init__(self, name, description, function, number_of_args):
        self._name = name
        self._description = description
        self._function = function
        self._logger = logging.getLogger("command")
        self._successful = False

        self.number_of_args = number_of_args

    def __str__(self):
        return "%s%s%s" % (self._name.ljust(35), str(self.number_of_args).ljust(5), self._description.rjust(60))

    def __setup(self):
        self._logger.debug("Executing command: %s", self._name)

    def __teardown(self):
        if self._successful:
            self._logger.info("Done")
        else:
            self._logger.info("Failed")

    def execute(self, *args):
        self.__setup()

        self._successful = self._function(self._logger, *args)

        self.__teardown()


"""
add your command here

"""


@accepts_static(logging.Logger)
@returns(bool)
def print_help(logger):
    """
    prints out the list of all available commands
    """
    logger.info("-" * 100)
    logger.info("Name".ljust(35) + "Number of arguments".ljust(20) + "Description".rjust(45))
    logger.info("-" * 100)

    for name in sorted(list_of_commands):
        logger.info(list_of_commands[name])

    logger.info("-" * 100)

    return True


list_of_commands["Help".lower()] = Command("Help", "prints out this help", print_help, 0)


@accepts_static(logging.Logger)
@returns(bool)
def print_sw_version(logger):
    """
    prints out the software version of this library including the built date
    """
    logger.info(get_version())

    o, e, r = cmd("version", print_command=False)
    logger.info(o)

    return True


list_of_commands["SWversion".lower()] = Command("SWversion", "prints out the software version", print_sw_version, 0)


@accepts_static(logging.Logger)
@returns(bool)
def sdram_memory_test(logger):
    """
    performs a ddr test calling the "memtester" utility
    """

    o, e, r = cmd("memtester 800M 1", timeout=30 * 60)

    logger.info(o)
    logger.info(e)

    return r


list_of_commands["SdRamMemoryTest".lower()] = Command("SdRamMemoryTest", "performs a DDR memory test",
                                                      sdram_memory_test, 0)


@accepts_static(logging.Logger)
@returns(bool)
def emmc_memory_test(logger):
    """
    calls the file test to the emmc device
    """

    return device_test(logger, "/dev/mmcblk1p1")


list_of_commands["eMMCMemoryTest".lower()] = Command("eMMCMemoryTest", "performs a test of the emmc", emmc_memory_test,
                                                     0)


@accepts_static(logging.Logger, str)
@returns(bool)
def sdcard_memory_test(logger, slot):
    """
    calls the file test to the sd card
    """
    return device_test(logger, "/dev/mmcblk0p1" % slot)


list_of_commands["SdCardMemoryTest".lower()] = Command("SdCardMemoryTest", "performs a test of the sdcard",
                                                       sdcard_memory_test, 0)


@accepts_static(logging.Logger, str)
@returns(bool)
def usb_memory_test(logger, port):
    """
    calls the file test to the USB stick
    """
    map = ['a', 'b', 'c', 'd', 'e']

    stick_number = int(port)
    if stick_number >= 0 and stick_number <= 4:
        port_str = map[stick_number]

        return device_test(logger, "/dev/sd%s1" % port_str)


list_of_commands["USBMemoryTest".lower()] = Command("USBMemoryTest a", "performs a test of USB stick a (0-4)", usb_memory_test, 1)


@accepts_static(logging.Logger)
@returns(bool)
def eeprom_memory_test(logger):
    """
    perform a file test on the Eeprom
    """

    # reset the eeprom to all zeros
    target = "/sys/bus/i2c/devices/0-0050/eeprom"
    o, e, r = cmd("dd if=/dev/zero bs=1 count=256 of=%s" % (target), timeout=20)

    if not r:
        logger.info("resetting the eeprom to all zeros failed")
        return False

    for i in range(0, 10):
        logger.info("executing iteration %d of 10" % (i + 1))
        try:
            r = file_test(logger, "/sys/bus/i2c/devices/0-0050/eeprom")
        except Exception as e:
            logger.info(e)
            r = False
            break

    if r:
        o, e, r = cmd("dd if=/dev/zero bs=1 count=256 of=%s" % (target), timeout=20)

    return r


list_of_commands["EepromMemoryTest".lower()] = Command("EepromMemoryTest", "performs a test of the eeprom",
                                                       eeprom_memory_test, 0)


# @accepts_static(logging.Logger, str, str, str, str, str, seconds=str) #doesn't work because we're calling with *args and that's not supported
@returns(bool)
def set_rtc(logger, year, month, day, hour, minutes, seconds="0"):
    """
    uses the busybox date & hwclock commands to set the RTC
    """

    # make sure /sys/bus/i2c... rtc0 exists, so we're talking to the correct rtc0
    o, e, r = cmd("cat /sys/bus/i2c/devices/0-0068/rtc/rtc0/date")
    if r:
        date_set_string = "%s.%s.%s-%s:%s:%s" % (year, month, day, hour, minutes, seconds)

        o, e, r = cmd("date -s %s" % date_set_string, timeout=1)
        logger.info(o)
        logger.info(e)
        if r:
            o, e, r = cmd("hwclock -w")
            logger.info(o)
            logger.info(e)

    else:
        logger.info("RTC not found")

    return r


list_of_commands["SetRTC".lower()] = Command("SetRTC a b c d e [f]",
                                             "sets the RTC (year, month, day, hour, minutes, [seconds])", set_rtc, 5)


@accepts_static(logging.Logger)
@returns(bool)
def get_rtc(logger):
    """
    returns the date, from the RTC
    """

    # make sure /sys/bus/i2c... rtc0 exists, so we're talking to the correct rtc0
    o, e, r = cmd("cat /sys/bus/i2c/devices/0-0068/rtc/rtc0/date")
    if r:
        date_get_string = '+"%Y %m %d %H %M %S"'
        o, e, r = cmd("date %s" % date_get_string, timeout=1, print_command=False)
        logger.info(o)
        logger.info(e)

    else:
        logger.info("RTC not found")

    return r


list_of_commands["GetRTC".lower()] = Command("GetRTC", "gets the RTC date", get_rtc, 0)


@accepts_static(logging.Logger, str)
@returns(bool)
def enable_dhcp(logger, interface):
    """
    will attempt to get an IP through DHCP
    """

    o, e, r = cmd("udhcpc -i %s" % (interface), 3)

    logger.info(o)
    logger.info(e)

    return r


list_of_commands["SetupDHCP".lower()] = Command("SetupDHCP a", "Try getting an IP from DHCP/Bootp on interface a",
                                                enable_dhcp, 1)


@accepts_static(logging.Logger, str, str)
@returns(bool)
def config_mac(logger, interface, address):
    """
    Change the mac address
    """

    o, e, r = cmd("ip link set dev %s down" % (interface))
    logger.info(o)
    logger.info(e)

    if r:
        o, e, r = cmd("ip link set dev %s address %s" % (interface, address))
        logger.info(o)
        logger.info(e)

    # to make it persistent, set it in the U-boot environment (in Flash) via fw_setenv
    # both fec_addr and ethaddr should be set
    if r:
        o, e, r = cmd("fw_setenv fec_addr %s" % address)
        logger.info(o)
        logger.info(e)

    if r:
        o, e, r = cmd("fw_setenv ethaddr %s" % address)
        logger.info(o)
        logger.info(e)

    if r:
        o, e, r = cmd("ip link set dev %s up" % (interface))
        logger.info(o)
        logger.info(e)

    return r


list_of_commands["ConfigMacData".lower()] = Command("ConfigMacData a b",
                                                    "Set the MAC address (e.g. eth0 11:22:33:44:55:66)", config_mac, 2)


@accepts_static(logging.Logger, str, str, str)
@returns(bool)
def config_static_ip_address(logger, interface, address, netmask):
    """
    Change the ip address
    """

    o, e, r = cmd("ifconfig %s %s netmask %s" % (interface, address, netmask))
    logger.info(o)
    logger.info(e)

    return r


list_of_commands["ConfigStaticIpAddress".lower()] = Command("ConfigStaticIpAddress a b c",
                                                            "Set a static IP address (e.g. eth0 192.168.100.150 255.255.255.0)",
                                                            config_static_ip_address, 3)


@accepts_static(logging.Logger, str)
@returns(bool)
def config_static_ip_gateway(logger, address):
    """
    Change the ip default gateway
    """

    o, e, r = cmd("route add default gw %s" % address)
    logger.info(o)
    logger.info(e)

    return r


list_of_commands["ConfigStaticIpGateway".lower()] = Command("ConfigStaticIpGateway a",
                                                            "Set the static IP gateway (e.g. 192.168.100.1)",
                                                            config_static_ip_gateway, 1)


@accepts_static(logging.Logger, str)
@returns(bool)
def eth_disable(logger, port):
    """
    Disable ethernet port
    """

    o, e, r = cmd("ifconfig %s down" % port)
    logger.info(o)
    logger.info(e)

    return r


list_of_commands["EthDisable".lower()] = Command("EthDisable a", "Disable Ethernet port (e.g. eth0)", eth_disable, 1)


@accepts_static(logging.Logger, str)
@returns(bool)
def eth_enable(logger, port):
    """
    Enable ethernet port
    """

    o, e, r = cmd("ifconfig %s up" % port)
    logger.info(o)
    logger.info(e)

    return r


list_of_commands["EthEnable".lower()] = Command("EthEnable b", "Enable Ethernet port (e.g. eth1)", eth_enable, 1)


@accepts_static(logging.Logger)
@returns(bool)
def eth_enable_all(logger):
    """
    Enable all ethernet ports
    """
    o, e, r = cmd("ifconfig -a", print_command=False)

    if r:
        interfaces = o.split("\n\n")
        for interface_str_all in interfaces:
            if interface_str_all:
                interface_name = interface_str_all.split()[0]
                if "eth" in interface_name:
                    eth_enable(logger, interface_name)
                    logger.info("Enabling %s" % (interface_name))
                    # else:
                    #    logger.info('Warning: interface "%s" is not an ethernet port, not calling Enable()' % interface_name)

    return r


list_of_commands["EthEnableAll".lower()] = Command("EthEnableAll", "Enable all Ethernet port", eth_enable_all, 0)


@accepts_static(logging.Logger, str, str)
@returns(bool)
def sci_send(logger, channel, message):
    """
    send a message on SCI (e.g. RS485)
    """

    import serial

    channel_int = int(channel)

    if channel_int == 2:
        # set the enable pin for RS485 transmit
        with open("/home/gpio/rs485_en", "wb") as f_rs485_en:
            f_rs485_en.write("1")

    if channel_int == 1:
        # clear the data enable pin for SAN transmit
        with open("/home/gpio/san_en", "wb") as f_san_en:
            f_san_en.write("1")

    with serial.Serial("/dev/ttymxc%s" % channel, baudrate=115200, timeout=0) as sci_out:
        sci_out.write(message)
        sci_out.flush()

    if channel_int == 2:
        # clear the data enable pin for RS485 receive
        with open("/home/gpio/rs485_en", "wb") as f_rs485_en:
            f_rs485_en.write("0")

    if channel_int == 1:
        # clear the data enable pin for SAN receive
        with open("/home/gpio/san_en", "wb") as f_san_en:
            f_san_en.write("0")

    return True

list_of_commands["SciSend".lower()] = Command("SciSend a b", "SCI Send message b on channel a (0-3)", sci_send, 2)


@accepts_static(logging.Logger, str)
@returns(bool)
def sci_receive(logger, channel):
    """
    receive a message on SCI (e.g. RS485)
    """

    import serial

    channel_int = int(channel)

    if channel_int == 2:
        # clear the data enable pin for RS485 receive
        with open("/home/gpio/rs485_en", "wb") as f_rs485_en:
            f_rs485_en.write("0")

    if channel_int == 1:
        # clear the data enable pin for SAN receive
        with open("/home/gpio/san_en", "wb") as f_san_en:
            f_san_en.write("0")

    with serial.Serial("/dev/ttymxc%s" % channel, baudrate=115200, timeout=1) as sci_in:
        received_message = sci_in.readline()

        if len(received_message) > 0:
            logger.info(received_message)
            return True

    return False

list_of_commands["SciRead".lower()] = Command("SciRead a", "SCI Receive message on channel a (0-3)", sci_receive, 1)

@accepts_static(logging.Logger, str)
@returns(bool)
def spi_pot_set(logger, value):
    """
    set value to the SPI dac (digital potentiometer)
    """


    if int(value) > 0 and int(value) < 255:
        with open("/sys/bus/spi/devices/spi0.0/rdac0", "w") as rdac_fh:
            rdac_fh.write(value)

        return True

    return False

list_of_commands["DigitalPotSet".lower()] = Command("DigitalPotSet a", "Set value to the digital potentiometer (0-255)", spi_pot_set, 1)

@accepts_static(logging.Logger)
@returns(bool)
def spi_pot_get(logger):
    """
    set value to the SPI dac (digital potentiometer)
    """

    with open("/sys/bus/spi/devices/spi0.0/rdac0", "r") as rdac_fh:
        logger.info(rdac_fh.read())

    return True


list_of_commands["DigitalPotGet".lower()] = Command("DigitalPotGet", "Get value of the digital potentiometer", spi_pot_get, 0)

@accepts_static(logging.Logger)
@returns(bool)
def check_sanrf(logger):
    """
    Check if the SAN RF i2c device is present
    """

    #
    o, e, r = cmd("i2cdetect -y 2 0x1f 0x1f", print_command=False)

    if r and "1f" in o:
        return True

    return False


list_of_commands["CheckSANRF".lower()] = Command("CheckSANRF", "Check i2c connection of the SAN RF", check_sanrf, 0)


"""
helper functions
"""


@accepts_static(logging.Logger, str)
def device_test(logger, device):
    """
    The device test is a simple test that writes X files to a linux block device (USB stick, SD card, Emmc...)
    and then reads back the written files, checking of the file was written ok.

    :param str device: /dev/mmcblk0p1 of zo
    :param logging.Logger logger: the logger to write the logging to
    :return: True/False
    """

    o, e, r = mount_device(device)
    logger.info(o)
    logger.info(e)

    if r:

        for i in range(0, 10):
            logger.info("executing iteration %d of 10" % (i + 1))
            try:
                r = file_test(logger, "/mnt/test/test%d.txt" % i)
                cmd("rm /mnt/test/test%d.txt" % i)
            except Exception as e:
                logger.info(e)
                r = False
                break

    unmount_device(device)

    return r


@accepts_static(logging.Logger, str)
def file_test(logger, file):
    """
    The file test writes to a file and reads back the data

    :param file: /mnt/test or somethin similar
    :param logger: the logger to write the logging to
    :return: True/False
    """
    random_number = random.randint(1, 100)
    text = "dit is test nummer %d\n" % random_number

    r = True

    with open(file, 'w') as f_write:
        f_write.write(text)

    cmd("sync")
    time.sleep(0.1)

    with open(file, 'r') as f_read:
        read_line = f_read.read(len(text))
        if read_line != text:
            logger.info("test case failed: read '%s'" % (read_line))
            r = False

    cmd("sync")

    return r


@accepts_static(str)
def unmount_device(device):
    cmd("umount %s" % device)
    cmd("rmdir /mnt/test")


@accepts_static(str)
def mount_device(device):
    # try some cleanup
    cmd("umount /mnt/test")
    cmd("mkdir -p /mnt/test")

    # try mounting the device
    return cmd("mount %s /mnt/test" % device)
