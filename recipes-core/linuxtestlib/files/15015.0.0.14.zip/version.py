"""
Generic version python file
Compatible python 2.7 - 3+



Copyright (c), PsiControl Mechatronics NV, All rights reserved.
"""
import sys

PRODUCT_ID_NUMBER =       15015       #<PRODUCT_ID_NUMBER>
PRODUCT_VERSION_NUMBER =  0           #<PRODUCT_VERSION_NUMBER>
PRODUCT_REVISION_NUMBER = 0           #<PRODUCT_REVISION_NUMBER>
PRODUCT_TEST_NUMBER =     14           #<PRODUCT_TEST_NUMBER>

def get_version_number():
    return "%d.%d.%d.%d" % (PRODUCT_ID_NUMBER, PRODUCT_VERSION_NUMBER, PRODUCT_REVISION_NUMBER, PRODUCT_TEST_NUMBER)

def get_version(show_name = True):
    line1 =  "%s%s" % (get_version_number(), (" - " + sys.argv[0] if show_name else "") )
    line2 = "built $DateTime: 2015/10/15 17:16:05 $".replace("$", "").replace("DateTime: ", "") # Perforce will fill in the submit date here, but we need to filter out the tags so it gets returned in our own format
    return "\n".join([line1, line2])

if __name__ == "__main__":
    print (get_version(False))