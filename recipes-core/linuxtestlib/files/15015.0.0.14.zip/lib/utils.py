#!/usr/bin/python
import sys

import os
import subprocess
import time

# -------------------------------------------------------------------------------------------------
def cmd(command, timeout=10, print_command=True):
    """
    generic function to execute a command, abstracting the Popen method
    It catches all output (out & err) and the returncode
    A timeout functionality was implemented as well, supporting both Python 2.7 & Python 3.3+

    :param command: the shell command to execute
    :param timeout: timeout in seconds
    :return: tuple of out_str, err_str, bool success
    """

    out = ""
    retval = 0
    err = ""

    if print_command:
        out = command + "\n"
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    if hasattr(subprocess, "TimeoutExpired"): # python 3+

        try:
            out_b, err_b = p.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            p.kill()
            out_b, err_b = p.communicate()

        out += out_b.decode(errors='ignore')
        err = err_b.decode(errors='ignore')
        retval = p.returncode

    else: # python 2.7
        if timeout:
            wait = 0
            while p.poll() is None and wait < 20:
                time.sleep(timeout/20)
                wait += 1

            if p.poll is None:
                p.terminate()
                time.sleep(timeout/20)

            if p.poll is None:
                p.kill()
                time.sleep(timeout/20)

            if p.poll is None:
                err += "Failed to kill process due to timeout"
                retval = 1

        if p.poll is not None:
            o, err = p.communicate()
            out += o
            retval = p.returncode

    
    return (out, err, retval == 0)
    
