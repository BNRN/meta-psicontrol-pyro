"""

SECTION 1 - Usage example

"""


# @accepts_static(int)
# def func(x):
#     return x
#
# @returns(str)
# @accepts_static(int, int, z=int)
# def func2(x,y,z):
#     return x+y+z
# class MyClass:
#     def __init__(self):
#         pass
#
#     @accepts(str)
#     @returns(str)
#     def myFunc(self, str):
#         return str
# def main():
#
#     x=1
#     y=2
#     print(func2(1,1,z=3))
# if __name__ == "__main__":
#     main()


"--------------------------------------------------------------------------------------------------------"
"""
SECTION 2 - Usage, rules and documentation.

@accepts_static  : typechecks incomming arguments of static functions
@accepts         : typechekcs incomming arguments of memeber functions
@returns         : typechecks return type of function
@returns_none    : typechecks return type of function (None is allowed)


Rules and guidelines:

1) When dealing with member functions of a class use @accepts, when dealing with a static function use @accepts_static
     This has to to with the fact that member function always have 'self' as first argument, which should be ignored.
     Static functions should have all arguments checked.

2) When default arguments are passed to a function (to override the default) this HAS to be done as a kwarg.
      @accepts_static(int, b=str)
      foo(a, b=''):
        pass
        
      foo(1)       -> OK
      foo(1,b='b') -> OK
      foo(1, b)    -> NOT OK!
      
3) Args should be passed as args, and not as kwargs

      @accpets_static(int, int)
      foo(a,b):
          pass
          
     foo(1,1)        -> OK
     foo(a=1,b=1)    -> NOT OK
     foo(b=1, a=1)   -> NOT OK
     foo(1, b=1)     -> NOT OK


Explanation of the rules:
    
Consider the following two funtions:
@accepts_static(int, float, z=str)        #argTypes = [int, float] kwargTypes=[z=str]
def foo(x,y,z=""):
    return 
     
@accepts_static(int,float,z=str,w=list)   #argTypes = [int, float] kwargTypes = {z:str, w:list}
def bar(x,y,z="",w=[]):
    return   
     

#SUCCESS
#The following examples all succeed
     
     
    #example 1:
    foo(1, 2.0, z="a")              args   = (1, 2.0) -> argtypes   = (int float)
                                    kwargs = {z="a"}  -> kwargtypes = {z=str}
                                     
                                    Args and argtypes and kwargs and kwargtypes map one to one, so no problem.
                                 
#-----------------------------------------------------------------------------------------------------------------------------------   
    #example 2:
    foo(1, 2.0)                     args   = (1, 2.0) -> argtypes = (int, float)
                                    kwargs = {}       -> kwargtypes = {z=str}
                                     
                                    all args given have the correct types, and all kwargs GIVEN too. 
                                    A default argument can't have the 'wrong' type so all is ok
                                 
#-----------------------------------------------------------------------------------------------------------------------------------    
                                     
    #example 3:
    bar(1, 2.0, z="z",w=[])         args   = (1, 2.0)       -> argtypes   = (int float)
                                    kwargs = {z="a", w=[]}  -> kwargtypes = {z=str, w=list}
                                     
                                    All args and all kwargs map one to one, so OK.
                                 
#-----------------------------------------------------------------------------------------------------------------------------------
    #example 4:
    bar(1, 2.0, z="z")              args   = (1, 2.0) -> argtypes   = (int float)
                                    kwargs = {z="a"}  -> kwargtypes = {z=str, w=list}
                                     
                                    args map one to one, and all given kwargs are also OK. (missing 'w' is default so can't be wrong)
                                  
#-----------------------------------------------------------------------------------------------------------------------------------     
    #FAIL
    #The following examples don't or cannot work.
     
#-----------------------------------------------------------------------------------------------------------------------------------   
    #example 5(fail):
    foo(1, 2.0, "z")                args   = (1, 2.0, "z") -> argtypes   = (int, float)
                                    kwargs = {}            -> kwargtypes = {z=str}
                                     
                                    This could work but is disallowed. Since there is only one extra arg and only one kwarg
                                    we could know what is meant by this. The problem is that this can only work for when 1
                                    default parameter is passed as arg. As soon as you give two, it is impossible to get right
                                    due to the unordered nature of dict keys. See example TODO NUMBER THIS ONE
                                    Use the syntax of example 1 instead.
                                 
#-------------------------------------------------------------------------------------------------------------------------------------  
    #example 6(fail):
    bar(1,2,"z",[])                 args   = (1, 2.0, "z", [])  -> argtypes   = (int, float)
                                    kwargs = {}                 -> kwargtypes = {z=str, w=list}
                                     
                                    This one can't work since we have two excess args. And since kwargtypes is a dict (which has
                                    unordered keys) we cannot know which of the exces arguments is which key and therefore we
                                    cannot know what the type is.
                                  
#-------------------------------------------------------------------------------------------------------------------------------------    
    #example 7(fail):
    bar(x=1,y=2.0,z="z",w=[])       args   = ()                      -> argtypes   = (int, float)
                                    kwargs = {x=1, y=2, z=z, w=[]}   -> kwargtypes = {z=str, w=list}
     
                                    We have two excess kwargs and no way to know to which argtype they map to.
                                 


"--------------------------------------------------------------------------------------------------------"

SECTION 3 - Code
"""
import os
import sys


def accepts_static(*argtypes, **kwargtypes):
    '''Function decorator. Checks decorated function's arguments are
    of the expected types.
    
    @note: use this one for static functions (functions that are not members of a class)
            -> don't ignore the first argument since it's not 'self'


    Parameters:
    types -- The expected types of the inputs to the decorated function.
             Must specify type for each parameter.

    '''

    def decorator(f):
        def newf(*args, **kwargs):
            # check args and argtypes
            assertionMessageArgs = "Number of positional arguments to check ({}) doesn't match number passed to function ({}).".format(len(args), len(argtypes))
            if (len(args) == (len(argtypes) + 1)):
                assertionMessageArgs += "\nPerhaps you used @accepts_static for a member function. Use @accepts instead."
            assert len(args) == len(argtypes), assertionMessageArgs
            argtypesPassed = tuple(map(type, args))


            # Check kwargs and kwargtypes
            assertionMessageKwargs = """"Number of keyword arguments passed ({}) is larger than keyword argument
                                             types to check. ({})""".format(len(kwargs.keys()), len(kwargtypes.keys()))
            assert len(kwargs.keys()) <= len(kwargtypes.keys()), assertionMessageKwargs

            kwargtypesPassed = {}
            for key in kwargs.keys():
                kwargtypesPassed[key] = type(kwargs[key])

            # Checks args
            for i in range(len(args)):
                if not isinstance(args[i], argtypes[i]):
                    #cast 'int' to 'float':
                    if type(args[i]) == int and argtypes[i] == float:
                        continue

                    msg = infoAccepts(f.__name__, argtypes, argtypesPassed, kwargtypes, kwargtypesPassed)
                    raise TypeError(msg)


            # Checks kwargs
            for key in kwargtypesPassed.keys():
                assert key in kwargtypes, "Keyword argument passed ({k}) is not in kwargtypes of function: {fn}".format(k=key, fn=f.__name__)
                if not isinstance(kwargs[key], kwargtypes[key]):
                    #cast 'int' to 'float':
                    if type(kwargs[key]) == int and kwargtypes[key] == float:
                        continue
                    msg = infoAccepts(f.__name__, argtypes, argtypesPassed, kwargtypes, kwargtypesPassed)
                    raise TypeError(msg)
            return f(*args, **kwargs)
        newf.__name__ = f.__name__
        return newf
    return decorator

def accepts(*argtypes, **kwargtypes):
    '''Function decorator. Checks decorated function's arguments are
    of the expected types.

    Parameters:
    argtypes   -- The expected types of the inputs to the decorated function.
                  Must specify type for each parameter EXCEPT 'self'
    
    kwargtypes -- The expected types of the inputs to the decorated function.
                  Must specify type for each parameter
                  
                  
    @note: 
    The problem is that a member function of a class looks like this:
    class MyClass:
        def myfunc(self,stri):
            return stri
    
    To annotate this we would have used:
    
    class MyClass:
        @accepts(MyClass, str)
        def myfunc(self,stri):
            return stri

    But MyClass isn't known yet so this raises errors. Therefore the first argument; 'self', is ignored.
    For functions that are not member function, you should use @accepts_static.

    '''


    def decorator(f):
        def newf(*args, **kwargs):
            # check args and argtypes
            assertionMessageArgs = "Number of positional arguments to check doesn't match number passed to function."
            if (len(args) == (len(argtypes) - 1)):
                assertionMessageArgs += "\nPerhaps you used @accepts for a static function? Use @accepts_static instead."
            assert len(args) - 1 == len(argtypes), assertionMessageArgs
            argtypesPassed = tuple(map(type, args))


            # Check kwargs and kwargtypes
            assertionMessageKwargs = """"Number of keyword arguments passed ({}) is larger than keyword argument
                                             types to check. ({})""".format(len(kwargs.keys()), len(kwargtypes.keys()))
            assert len(kwargs.keys()) <= len(kwargtypes.keys()), assertionMessageKwargs

            kwargtypesPassed = {}
            for key in kwargs.keys():
                kwargtypesPassed[key] = type(kwargs[key])

            # Checks args
            for i in range(len(args) - 1):
                if not isinstance(args[i + 1], argtypes[i]): # Skip 'self'
                    #cast 'int' to 'float':
                    if type(args[i+1]) == int and argtypes[i] == float:
                        continue
                    msg = infoAccepts(f.__name__, argtypes, argtypesPassed[1:], kwargtypes, kwargtypesPassed)
                    raise TypeError(msg)

            # Checks kwargs
            for key in kwargtypesPassed.keys():
                assert key in kwargtypes, "Keyword argument passed ({k}) is not in kwargtypes of function {fn}".format(k=key, fn=f.__name__)
                if not isinstance(kwargs[key], kwargtypes[key]):
                    #cast 'int' to 'float':
                    if type(kwargs[key]) == int and kwargtypes[key] == float:
                        continue
                    msg = infoAccepts(f.__name__, argtypes, argtypesPassed[1:], kwargtypes, kwargtypesPassed)
                    raise TypeError(msg)
            return f(*args, **kwargs)
        newf.__name__ = f.__name__
        return newf
    return decorator



def returns_none(ret_type):
    """Function decorator. Checks decorated function's return value
    is of the expected type or None
    

    Parameters:
    ret_type -- The expected type of the decorated function's return value.
                Must specify type for each parameter.
    """
    msg="undefined"
    try:
        def decorator(f):
            def newf(*args, **kwargs):
                result = f(*args, **kwargs)
                if result is None:
                    return result
                res_type = type(result)
                if not isinstance(result, ret_type):
                    #cast 'int' to 'float':
                    if type(result) == int and ret_type == float:
                        pass
                    else:
                        msg = infoReturns(f.__name__, ret_type, res_type)
                        raise TypeError(msg)
                return result
            newf.__name__ = f.__name__
            return newf
        return decorator
    except TypeError(msg):
        raise TypeError(msg)

def returns(ret_type):
    """Function decorator. Checks decorated function's return value
    is of the expected type or None
    

    Parameters:
    ret_type -- The expected type of the decorated function's return value.
                Must specify type for each parameter.
    """
    msg = "undefined"
    try:
        def decorator(f):
            def newf(*args, **kwargs):
                result = f(*args, **kwargs)
                if result is None:
                    return result
                res_type = type(result)
                if not isinstance(result, ret_type):
                    msg = infoReturns(f.__name__, ret_type, res_type)
                    raise TypeError(msg)
                return result
            newf.__name__ = f.__name__
            return newf
        return decorator
    except TypeError(msg):
        raise TypeError(msg)

def infoAccepts(fname, expectedArgs, actualArgs, expectedKwargs, actualKwargs):
    """Convenience function returns nicely formatted error/warning msg."""

    def getFullName(arg):
        if arg.__module__ == 'builtins':
            return str(arg)
        return arg.__module__ + "." + arg.__class__.__name__

    def format(args, kwargs):
        outp = ""
        for arg in args:
            outp += getFullName(arg) + ', '
        for key in kwargs.keys():
            kwarg = kwargs[key]
            outp += str(key) + "=" + getFullName(kwarg) + ', '
        return outp.rstrip(', ')

    expected, actual = format(expectedArgs, expectedKwargs), format(actualArgs, actualKwargs)

    msg = "'{}' method ".format(fname)\
          + "accepts ({}), but ".format(expected)\
          + "was given ({})".format(actual)
    return msg


def infoReturns(fname, expectedType, actualType):
    """Convenience function returns nicely formatted error/warning msg."""

    format = lambda type: str(type).split("'")[1]

    expected, actual = format(expectedType), format(actualType)

    print(expected)
    print(actual)

    msg = "'{}' method ".format(fname)\
          + "returns ({}), but ".format(expected)\
          + "result is ({})".format(actual)
    return msg
