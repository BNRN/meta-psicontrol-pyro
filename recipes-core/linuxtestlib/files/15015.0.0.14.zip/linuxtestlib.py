"""
linuxtestlib.py
Compatible python 2.7 - 3+

Copyright (c), PsiControl Mechatronics NV, All rights reserved.
"""
from version import *

import sys
import os
import logging

path = os.path.abspath(os.path.join(__file__, '..', '..', '../15016/main'))  # 2015
if path not in sys.path:
    sys.path.append(path)

import argparse
from lib.TypeChecking import *
import Commands

# configure the command logger
logger = logging.getLogger("command")
logger.setLevel(logging.INFO)

# set the logger to log to the console
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)

# the format is simple: just the message
formatter = logging.Formatter("%(message)s")
ch.setFormatter(formatter)
logger.addHandler(ch)

@returns(argparse.ArgumentParser)
def get_argument_parser():
    parser = argparse.ArgumentParser(prog=get_version_number())
    parser.add_argument("command",  help="command to execute")
    parser.add_argument("arg1", nargs="?", help="optional argument a")
    parser.add_argument("arg2", nargs="?", help="optional argument b")
    parser.add_argument("arg3", nargs="?", help="optional argument c")
    parser.add_argument("arg4", nargs="?", help="optional argument d")
    parser.add_argument("arg5", nargs="?", help="optional argument e")
    parser.add_argument("arg6", nargs="?", help="optional argument f")

    return parser

@accepts_static(list)
def main(argv):
    parser = get_argument_parser()
    args = parser.parse_args()
    optional_arg_list = []
    if args.arg1:
        optional_arg_list.append(args.arg1)
    if args.arg2:
        optional_arg_list.append(args.arg2)
    if args.arg3:
        optional_arg_list.append(args.arg3)
    if args.arg4:
        optional_arg_list.append(args.arg4)
    if args.arg5:
        optional_arg_list.append(args.arg5)
    if args.arg6:
        optional_arg_list.append(args.arg6)

                
    return execute(args.command, *optional_arg_list)

#@accepts_static(str)
def execute(command, *args):
    """
    executes the requested command
    """

    if command.lower() in Commands.list_of_commands:
        if len(args) >= Commands.list_of_commands[command.lower()].number_of_args:
            Commands.list_of_commands[command.lower()].execute(*args)
        else:
            logger.info(command)
            logger.info(" " * len(command) + "^ \nExpected %d arguments, got %d" % (Commands.list_of_commands[command.lower()].number_of_args, len(args)))
    else:
        logger.info(command)
        logger.info(" " * len(command) + "^ \nUnknown Cmd")


if __name__ == "__main__":
    main(sys.argv)